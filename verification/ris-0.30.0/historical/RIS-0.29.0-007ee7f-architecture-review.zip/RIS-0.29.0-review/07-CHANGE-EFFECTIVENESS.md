# 실패 지점, 구현 책임과 효과

질문·근거를 찾아낸 역할, 후보 판단을 통합한 Coordinator, 최종 답의 문단을 검증하는 helper, 독립 Auditor가 각각 어떤 손실을 볼 수 있는지가 검토의 핵심이다. 아래 경로와 행 번호는 모두 커밋 `007ee7ff2d727e813ba59584abc80e7b1c002e74`의 `moontaehyung/` 아래다. [변경 파일 전체와 Git blob](commit/FILES.tsv)

| 실패 지점과 실측 | 변경된 책임·구현 | 효과의 증거 | 남은 한계 |
|---|---|---|---|
| **탐색 범위·질문**. R02의 일부 초기 실행은 명목상 ‘하루’ 메타데이터를 제시하고 실제 사건의 시작·종료 시각을 계산하지 않았다. 다른 재실행에서는 역할이 직접 계산했다. | `skills/ris/references/self-critical-workflow.md`에서 사용자 결정에 필요한 관측과 실제 조사 범위를 대조한다. `ris_recovery.py`의 `recovery_action`·`transition`이 세 번째 유효 재요청에서 전수 모드를 즉시 선택한다. | 이전 통제 시나리오에서는 재요청 3회째 모든 관점 검토와 후보 계산, 4회째 메타 진단을 실제 관찰. [복구 기록](evidence/A/gt4/gt4-report.md.txt) | 모드 전환 자체가 실제 조사나 과학적 충분성을 보증하지 않는다. 최종 역할로 얻을 개선량 NOT_RUN |
| **근거 확보·도출**. R01의 보간·초기 품질정보 한계가 원문에 있었고 Researcher가 읽었다. R02의 타임스탬프도 주어졌고 일부 실행에서 출처→값 도출까지 확인됐다. | 공통 탐색 규칙과 Engineer·Researcher 계약은 해석 가능한 조건과 위치를 원 소유자가 반환하도록 한다. | [실제 계산 증거](roles/execution-excerpts.json)와 [역할 반환](roles/public-returns-and-receipts.json). 이 사례에서 원자료 접근 실패가 공통 원인이라는 설명은 성립하지 않는다. | 미계산 사례에서 검사를 선택하지 않은 내부 이유, 모든 원자료를 충분히 해석했는지는 UNKNOWN |
| **역할 간 전달과 소유권**. R02 delivery 실행의 두 역할은 정확한 시간 범위를 계산했지만 공개 반환에는 그 값이 없었다. R01은 반환과 수신에 보간 한계가 있었다. | `agents/researcher.toml`, `engineer.toml` 및 Claude 대응 파일은 검증 역할이 결과·관측범위·한계를 짧은 사용자용 문단으로 표시하는 책임을 진다. `role-workflow.md`와 Coordinator 템플릿이 원 반환과 revision을 대조한다. | [역할과 수신을 구분한 추적](04-ROLE-TRACE-AND-RCA.md). 최종 양 호스트 지침의 책임·모델·effort가 대응하는지는 [정적 대조](evidence/C/owner-installation/role-equivalence.json)로 확인. | 최종 owner 지침이 모든 필요한 항목을 골라 반환하게 만드는지는 NOT_RUN. 수신 이벤트로 그 문장을 이해했다고 판정할 수 없다. |
| **최종 답변 전달**. R01 개발 재실행은 연구 노트에 있던 한계를, R02 개발 재실행은 이미 도출·기록된 시간 범위를 최종 메시지에서 빠뜨렸다. | `ris.py delivery` → `ris_delivery.py`의 `read_file`, `passages`, `paragraphs`, `contains`, `dispatch`, `render`가 선택한 원문과 해시를 고정해 출력·초안 대조를 지원한다. [행 번호 포함 발췌](commit/excerpts/skills/ris/scripts/ris_delivery.py.txt) | 0.29.0 초기 초안에서 실제 helper 사용을 관찰. 수치 3→3.5를 허용한 오류는 문단 전체 매칭 수리 후 같은 반례를 거절. [독립 검사](evidence/C/delivery-review.md.txt) · [실제 답의 저장본에 대한 엄격 매칭](evidence/C/delivery-replay/final-retention.json) | 문단 선택 전에 정보가 빠지면 검사할 수 없다. 엄격 검사로 R02의 이전 답이 거절된 이유는 선택 문장 옆의 추가 문장까지 문단에 들어갔기 때문이다. 선택된 세 문장 자체는 있었다. 최종 모델의 수정 행동은 NOT_RUN |
| **평가기·독립성**. 최초 채점은 복합 항목의 일부 누락을 완전 충족으로 기록했다. 두 번째 판독과 답안별 근거 문장 대조로 부분 충족으로 수정했다. | 평가 방법의 수리는 답안별 근거·블라인드 판정 고정과 과거 점수 보존이다. 제품 내부에서는 `research-audit`가 범위 선고정 후 결과 공개와 수정 revision 재감사를 소유한다. 서로 다른 검증 층이다. | [채점 정정](evidence/A/evaluation/adjudication/coverage-dissent-resolution.json) · [독립 감사 체인](evidence/A/gt5/outputs/chain-verification.json) | 다른 해석이 가능한 루브릭 항목과 소표본 일반화는 남는다. 최종 역할의 과학적 완전성을 attest한 외부 전문가 판정 NOT_RUN |
| **자원·기한**. 330초에서 최종 답이 없는 실행이 있었고, 여러 사례에서 불필요한 디렉터리 확인·산출물 작업이 관측됐다. 최종 역할 재실행은 중단선에서 시작하지 않았다. | Coordinator의 마감 전 전달, artifact 소유자/경로 지정·완료 알림 기반 읽기 및 요청 산출물 범위가 달라졌다. 예산 사전 검사는 별도 평가 Host에 있다. | [비용 원인 조사](evidence/A/cost-diagnosis.md.txt) · [동일 자료의 회귀와 자원 실측](05-RESOURCES.md). 0.28.2 메모 사례에서 불필요한 Designer 호출 감소 관찰 | 앞서 완주한 연구의 모든 과학적 누락을 시간 부족에 귀속할 증거는 없다. 제공자 지연의 기여도, 청구액 및 최종 0.29.0의 총 비용 효과 UNKNOWN |

## 최종 소스에서 직접 읽을 위치

- [증거를 실제 결정 문장까지 넘기는 공통 절차](commit/excerpts/skills/ris/references/self-critical-workflow.md.txt)
- [요청의 의미적 계보와 세 번째 요청의 전환](commit/excerpts/skills/ris/scripts/ris_recovery.py.txt)
- [Coordinator의 배정·통합·공개 책임](commit/excerpts/templates/ris-coordinator-AGENTS.md.txt)
- [Researcher](commit/excerpts/agents/researcher.toml.txt) · [Engineer](commit/excerpts/agents/engineer.toml.txt) · [Auditor](commit/excerpts/agents/auditor.toml.txt)
- [독립 범위 공개 단계와 감사 책임](commit/excerpts/skills/research-audit/references/audit-contract.md.txt)

이들은 하나의 검증된 경우에서 다른 모든 연구에 효과가 난다는 증거가 아니다. 특히 지침을 배포했다는 사실, 문단 일치 검사가 성공했다는 사실, 별도 Auditor가 수치를 재현했다는 사실을 ‘누락 없는 최종 과학 답변’으로 승격할 수 없다.
