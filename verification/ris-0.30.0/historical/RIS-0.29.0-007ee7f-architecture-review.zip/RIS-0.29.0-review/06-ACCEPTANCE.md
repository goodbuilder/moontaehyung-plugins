# 인수 보고서와 독립성의 범위

**0.29.0 전체 인수를 승인한 독립 감사는 없다.** 서로 다른 질문에 대한 개발 감사, 제품 Auditor의 제한된 과제 판정, 버전을 가린 과학 답안 채점이 있다. 아래 자료는 각각의 대상과 결과를 그대로 보존한다.

| 검토 주체·대상 | 관측된 결론 | 해석 한계 |
|---|---|---|
| 독립 개발자, 복구 helper와 계약 | 경로·권한·CAS·재전송·미확인 횟수와 세 번째 전환을 시험. 당시 조사 범위의 blocking/major 결함 미확인. [개발 감사](evidence/A/development-audit.md.txt) · [후속 변경 대조](evidence/A/independent-final-audit.md.txt) | 개발 요구를 알고 같은 호스트를 사용한 코드 검토. 과학 성능 일반화 미검증 |
| 독립 개발자, 0.29.0 전달 helper | 선택 문구의 수치가 3에서 3.5로 바뀌어도 통과한 결함 재현. 문단 전체 비교로 수정하고 같은 반례의 거절과 적법한 줄바꿈 통과 확인. [감사 기록](evidence/C/delivery-review.md.txt) | 문자의 운반을 확인. 표시할 과학적 한계를 올바르게 골랐는지는 UNKNOWN |
| 제품 Auditor, 통제된 범위 재구성 | 기존 범위를 공개하기 전에 별도 Auditor가 범위를 고정. 공유된 보정 오차 누락 사례 FAIL, 정상 설계 PASS. Engineer 수정본은 새 범위 고정·재검수 후 조건부 설계 PASS. [결함 원판정](evidence/A/runs/gt5-audit-a/project-artifacts/audit/report-v1.md.txt) · [정상 대조](evidence/A/runs/gt5-audit-b/project-artifacts/audit/report-v1.md.txt) · [수정본](evidence/A/runs/gt5-reaudit/project-artifacts/audit/report-v2.md.txt) · [공개 순서·원본 보존](evidence/A/gt5/outputs/chain-verification.json) | 초기 일부 입력은 쓰기 가능했고 이후 단계와 새 감사에서는 패킷 쓰기 거부를 관찰. Host가 단계 공개를 제어한 과제와 Coordinator가 배정한 과제를 구별. 실제 센서 검증 미실행 |
| 제품 Auditor, 전수 탐색의 사후 범위 확인 | 10개 감사 영역에서 해당 범위 PASS. 미측정 후보의 성능과 절대 최적 여부는 UNKNOWN. [사후 감사](evidence/A/runs/gt4-independent-audit/project-artifacts/audit/review-v1.md.txt) | 호스트가 새 Auditor 세션을 시작했다. 원래 연구 턴의 자율 감사 실적으로 합산할 수 없음 |
| 과학 답안의 블라인드 판독 | 0.28.0·0.28.1의 답안과 출처를 별도 판독. 일부 개별 항목 이견은 점수 이력에 보존. [첫 연구 재판독](evidence/A/scoring/second-reader/summary.md.txt) · [확인 연구 재판독](evidence/B/independent-scores/blind-pair-verdicts.json) | 주제별 반복 2회. 외부 인간 도메인 전문가·실제 현장 사용자 검수 NOT_RUN |
| 최종 패키지와 Git 출처 | 287개 회귀 통과의 기존 로그·395개 해시·Codex/Claude 역할 동등성 확인. [원래 인수 보고서의 검토용 사본](evidence/C/REPORT.md.txt) · [푸시 영수증](evidence/C/push-007ee7f.json) | 보고서에 있는 당시 미커밋 설명은 역사다. 이후 검증된 소스를 커밋·푸시했다는 영수증을 현재 커밋 식별에 사용한다. 푸시는 인수 판정을 바꾸지 않았다. |

이 자료집에서 추가한 독립 검토용 작업은 기존 기록의 대조와 비식별화다. 기존 Auditor가 실제 검토한 revision, 검사 범위, PASS·FAIL·NOT_RUN은 원래 감사 결과를 따른다.
