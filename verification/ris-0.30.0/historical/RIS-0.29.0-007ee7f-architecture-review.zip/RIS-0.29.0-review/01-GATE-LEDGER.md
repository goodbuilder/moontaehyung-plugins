# Gate와 요구사항 검증 원장

검토 revision은 `007ee7ff2d727e813ba59584abc80e7b1c002e74`이다. **GT7은 NOT_RUN, GT8은 BLOCKED다.** 아래의 이전 PASS는 관측한 revision과 시나리오에 한정한다. CONFIRMED는 파일이나 실행에서 관측한 사실, UNKNOWN은 현재 근거만으로 결정할 수 없는 사실, NOT_RUN은 해당 범위의 실험 미수행을 뜻한다. BLOCKED는 실행·인수 조건의 상태다. [최종 당시의 인수 보고서](evidence/C/REPORT.md.txt) · [최종 요구사항 원장](evidence/C/TRACEABILITY.md.txt)

| Gate | 커밋 기준 판정 | 충족된 근거 | 미충족 또는 적용 한계 |
|---|---|---|---|
| GT0 기준 | PASS | 기준 0.27.1 Git 객체·대표 실험·입력 격리·사전 등록·회귀 결과. [기준 스냅샷](evidence/B/provenance/baseline.json) | 다음 48단계 연구의 실제 자원 가용성은 별도 BLOCKED |
| GT1 계약 | PASS | 관점·역할·방법 구분, 기존 breadth·권한·양 호스트 책임 검토. [최종 역할 대조](evidence/C/owner-installation/role-equivalence.json) | 정적 계약의 일관성을 확인한 범위 |
| GT2 적응 탐색 | NOT_RUN | 이전 통제 과제에서 반례, 작업자 반환, 후속 계산과 국소 변경을 관찰. [통제 관측](evidence/A/controlled/INDEX.md.txt) | 최종 역할과 전달 규칙을 적용한 동일 자연어 E2E 미실행 |
| GT3 연속성 | PASS | v1 원생성 프로젝트와 최종 CLI로 계보·재사용·조건·오래된 쓰기 검증. [v1 명령 종료 기록](evidence/C/continuity/v1-real-origin-results.json) · [계보 명령 종료 기록](evidence/C/continuity/lineage-cli-results.json) | 자동 의미 분류의 보편적 정확도 UNKNOWN |
| GT4 실패 복구 | NOT_RUN | 이전 자연어에서 세 번째 전수·네 번째 메타, CAS 충돌 복구와 예산 경계 확인. [실제 복구 경로](evidence/A/gt4/gt4-report.md.txt) · [전환 원장](evidence/A/gt4/gt4-release-verification.json) | 선택된 커밋의 helper 회귀는 통과했지만 최종 역할로 연구 수행까지 포함한 전체 복구 E2E 미실행 |
| GT5 독립 범위 | NOT_RUN | 결함·정상 대조, 선고정, owner 교정, 새 revision 검수의 이전 체인 확인. [감사 체인](evidence/A/gt5/outputs/chain-verification.json) | 최종 Auditor의 출처·누락 반환 책임 변경 후 실제 재실행 미수행 |
| GT6 전략 이전 | NOT_RUN | 이전 새 세션이 기존 전략을 검색하고 조건부로 적용, 비적용 대조 확인. [기존 조건부 이전 기록](evidence/A/controlled/transfer-finding.json) | 최종 역할 계약으로 다시 수행한 이전 연구 미수행 |
| GT7 실자료 품질 | **NOT_RUN** | 0.28.0·0.28.1 각각의 사전 등록 비교는 FAIL. [첫 비교](02-COHORT-0280.md) · [별도 확인 연구](03-COHORT-0281.md) | 최종 0.29.0 실제 품질 비교는 자원 사전 검사에서 BLOCKED |
| GT8 전체 인수 | **BLOCKED** | 제품 파일 정체성, 287개 회귀, 격리 설치 및 부분 독립 감사 확인. [코드 정체성](commit/IDENTITY.json) · [회귀 로그](evidence/C/owner-regression.log) | 필수 Gate가 최종 revision에서 모두 유효하다는 증거 부족 |

## R-01–R-27

각 행의 “이전 실행”은 비교 대상 버전을 명시한 자료에 연결한다. 이전 조건의 실제 동작과 현재 커밋의 정적·CLI 검증은 각각 별도로 읽어야 한다.

| 요구 | 주 Gate | 관측·한계와 근거 |
|---|---|---|
| R-01 기존 능력 파악 | GT0 | 0.27.1의 실제 기준 실행과 회귀, Study·Metric·질문별 출처 재사용·그래프 소유권 확인. [초기 원장](evidence/A/TRACEABILITY.md.txt) |
| R-02 개방형 관점 | GT1 | E01–E12 및 추가 관점 계약, 선택 기준. [공통 계약 발췌](commit/excerpts/skills/ris/references/self-critical-workflow.md.txt) |
| R-03 계약 일관성 | GT1 | 역할·관점·방법과 공개/재감사 시점 구분, 두 호스트 역할 일치. [역할 대조](evidence/C/owner-installation/role-equivalence.json) |
| R-04 적응형 선택 | GT2 | 입력 표현·메모리 제약에 따라 조사 우선순위를 변경한 이전 통제 실행. [GT2 기록](evidence/A/controlled/INDEX.md.txt) |
| R-05 다방향 재귀 | GT2 | 보정 결과와 현장 입력 반례에서 변환·정확성·자원 검사가 파생됨. [공개 역할 반환](evidence/A/controlled/return-evidence.json) |
| R-06 작업자 발견 | GT2 | 원래 맡지 않은 정수 변환 한계와 후속 검사. 일부 중간 통신의 정확한 전달 시각·본문은 UNKNOWN. [통제 원장](evidence/A/controlled/INDEX.md.txt) |
| R-07 원인·해법 양방향 | GT2/7 | 기존 계약과 원인/해법 점검 보존, 실제 향상 정도는 비교별로 판정. [0.28.1 비교](03-COHORT-0281.md) |
| R-08 의존성 기반 배정 | GT2 | 실제 네이티브 역할 실행과 반환을 관찰. 호스트가 역할을 지정한 통제 입력과 목적만 준 입력을 구분. [목적만 준 실행의 답](evidence/A/controlled/gt2-unaided-answer.txt) |
| R-09 연구·지식·결정 연결 | GT3 | 질문 ID·기존 원자료의 적용 범위·선택의 관계를 독립 CLI 프로세스에서 확인. [원래 기록의 위치](evidence/C/TRACEABILITY.md.txt) |
| R-10 세션 연속성 | GT3 | 원생성 v1과 새 세션이 프로젝트 상태를 복원. [명령 기록](evidence/C/continuity/v1-real-origin-results.json) |
| R-11 안정적 노드 ID | GT3/4 | 이름 변경, 의미 승계가 명시된 분할·병합과 공유 요청 중복 제거. [helper 발췌](commit/excerpts/skills/ris/scripts/ris_recovery.py.txt) |
| R-12 유효 재요청 관리 | GT4 | `rework_count`와 분리. 논리 요청 식별과 전달 후 심화, 재전송·설명 제외 관찰. [복구 실험](evidence/A/gt4/gt4-report.md.txt) |
| R-13 세 번째 즉시 전환 | GT4 | 새 세션에서 count 2→3, 같은 요청에서 `exhaustive_now`와 실제 후보 계산. [전환 검증](evidence/A/gt4/gt4-release-verification.json) |
| R-14 자율 부족 감지 | GT4 | 사용자 힌트 전 명목값과 지속 운전 측정의 충돌 발견. 모든 연구 부족의 감지율은 UNKNOWN. [관측 범위](evidence/A/gt4/gt4-report.md.txt) |
| R-15 전수의 실제 수행 | GT4 | 후보 8개와 등록 관점, 추가 관점, 미측정 조건을 검사한 이전 실행. [사후 독립 감사](evidence/A/runs/gt4-independent-audit/project-artifacts/audit/review-v1.md.txt) |
| R-16 메타 진단 | GT4 | 네 번째 유효 요청에서 실제 역산 및 실패 원인 가설 점검. [결과](evidence/A/gt4/gt4-release-verification.json) |
| R-17 무의미한 반복 방지 | GT4 | 동일 요청의 재전송, stale 복구, 새로운 측정 부재 시 재개 조건 보존. [복구 보고](evidence/A/gt4/gt4-report.md.txt) |
| R-18 안전·비용·권한 | GT4/8 | 수동 기록 경계, 읽기 전용 전달 도구와 경로 검사, 사전 중단선. [개발 감사](evidence/C/delivery-review.md.txt) · [실제 사전 검사](evidence/C/future-design/runner/live-preflight.json) |
| R-19 독립 범위 재구성 | GT5 | 원래 목표로 범위를 먼저 고정한 뒤 후보 공개. 초기 일부 scratch가 쓰기 가능했던 한계 포함. [체인 검증](evidence/A/gt5/outputs/chain-verification.json) |
| R-20 독립 감사·재작업 | GT5 | 결함 판별→실제 Engineer 교정→별도 Auditor 재검수. [수정본 검수](evidence/A/runs/gt5-reaudit/project-artifacts/audit/report-v2.md.txt) |
| R-21 전략 경험 축적 | GT6 | 일반 검색이 숨은 조건 파일을 놓친 실패와 회복을 기존 연구 노트에 저장. 초기 실패는 시험에서 유도한 경우를 포함. [조건부 기록](evidence/A/controlled/transfer-finding.json) |
| R-22 전략 조건부 재사용 | GT6 | 다른 과제에서 출처를 다시 확인하고 단위 근거를 찾아 1.5ms 산출, 비적용 대조. [최종 답](evidence/A/controlled/gt6-unaided-answer.txt) |
| R-23 기존 품질 기준 | GT7 | 이전 breadth·근거·인과·감사 기준 유지. 정정 전후 판정 구분. [판독 이견](evidence/A/evaluation/adjudication/coverage-dissent-resolution.json) |
| R-24 실제 품질 개선 | GT7 | 0.28.0·0.28.1 사전 합격 기준 미달. 최종 역할로 해결 여부 NOT_RUN. [확인 연구 판정](evidence/B/decision.json) |
| R-25 자원·사용자 개입 비교 | GT7 | 매칭된 실행 시간·모델 응답·캐시 포함 토큰 기록. 단일 요청 조건의 사용자 추가 회신은 0, 금전 비용과 실사용자 판단 시간 UNKNOWN. [자원](05-RESOURCES.md) |
| R-26 프로젝트·설치 호환성 | GT8 | 최종 395개 파일의 격리 설치와 역할 동등성, 최종 소스 회귀. [설치](evidence/C/owner-installation/summary.json) · [회귀](evidence/C/owner-regression.log) |
| R-27 최종 시스템 독립 인수 | GT8 | 개발 감사·제품 Auditor·연구 품질 판독을 분리했다. 최종 전체 인수 BLOCKED, 외부 도메인 전문가 판정 NOT_RUN. [인수·감사 안내](06-ACCEPTANCE.md) |
