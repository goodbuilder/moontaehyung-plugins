Synthetic lab report P. Table 2, row c. Larch-1 simulator, batch four, p95 delay = 15 milliseconds. Table 3, row a. Board Cedar, batch one, p50 = 11 milliseconds.
