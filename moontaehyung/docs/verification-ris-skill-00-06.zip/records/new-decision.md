# T4 · T5 판정

## T4 — 두 모델 주장과 판단을 바꿀 확인

**현재 지지할 수 있는 결론:** A와 B 중 어느 쪽이 일반적으로 더 빠르다고는 아직 지지할 수 없습니다. 주어진 합성 timing trial에서는 같은 기계·입력 설정의 batch 32에서 둘 다 110 ms였습니다. 그 한 점은 해당 조건에서 동률이라는 관측을 지지하지만, 다른 batch 크기에서의 우열은 보여 주지 않습니다.

A가 고정 setup 시간을 줄이고 B가 항목당 시간을 줄인다는 설명을 단순 가산 모델에 적용하면, 두 개선이 batch 32에서 같아지는 경우 32보다 작은 batch에서는 A, 큰 batch에서는 B가 유리할 수 있습니다. 이는 제공된 설명에서 나온 **모델 추론**이지, 다른 크기에서 확인된 결과가 아닙니다. 실제 batch 분포와 비선형 효과도 아직 모릅니다.

**판단을 가를 최소 확인:** Engineer의 역할 정의대로 측정 구성과 판정 기준을 먼저 고정합니다. 같은 기계, 입력, 소프트웨어 설정에서 A와 B를 작은 크기·32·큰 크기(예: 8·32·128)에 모두 적용하고, 각 조건의 전체 경과시간을 반복 측정합니다. 실행 순서를 번갈아 배치해 순서·부하 변화가 한 대안에만 치우치지 않게 하고, setup과 항목별 시간을 따로 기록할 수 있으면 두 설명도 직접 확인합니다. 실제 현장 batch 분포가 주어지면 그 분포에서의 총 시간을 비교합니다. 이 숫자들은 제안한 시험 수준이며, 관측 결과가 아닙니다.

- 반복 측정에서 A가 목표 batch 분포의 총 시간을 낮추면 A를 지지합니다.
- B가 낮추면 B를 지지합니다.
- 크기에 따라 우열이 바뀌면 현장 batch 분포가 결정을 가릅니다.
- 차이가 재현되지 않거나 측정 조건이 흔들리면 판정은 보류합니다. 그 결과를 우열로 바꾸지 않습니다.

RIS role-workflow의 경계에 따라 Engineer는 **무엇을 측정하고 어떤 관측이 기준을 충족하는지** 정의하며, Planner는 이 확인을 선택 전에 놓고 각 결과(보류 포함)가 어느 선택을 지원하는지 연결합니다. 이에 따라 위 측정은 다음 선택보다 앞서야 합니다. 현재 자료에는 목표 batch 분포나 시간 차이의 수용 기준이 없으므로, 그런 기준을 임의로 만들어 결론에 넣지 않았습니다.

**근거:** `inputs/two-models.txt`. 그 밖의 batch 크기 측정은 제공되지 않았습니다.

기록: 읽은 파일 — `inputs/request-decision.txt`, `inputs/two-models.txt`, `candidate/skills/ris/SKILL.md`, `candidate/skills/ris/references/role-workflow.md`, `candidate/agents/claude/engineer.md`, `candidate/agents/claude/planner.md`, `candidate/agents/engineer.toml`, `candidate/agents/planner.toml`; 수행 — 지정 파일을 읽고 역할 경계에 따라 직접 분석해 이 기록에 작성; 적용한 실제 역할 정의 — snapshot의 RIS Coordinator/좁은 답변 절차, Engineer, Planner. Engineer와 Planner는 역할 정의를 적용한 분석이며 별도 agent 실행은 하지 않았습니다.

## T5a — Rowan / workload K / revision 9

**판정: ACQ-793의 기록 범위에서는 A 사용을 지지합니다.** 해당 device log는 보드 Rowan, workload K, 요구 revision 9에 대해 p50 11.3 ms와 p95 18.6 ms를 기록했고 `simulation=false`입니다. 따라서 사용자가 제시한 p95 ≤20 ms 조건을 이 기록은 1.4 ms 여유로 충족합니다.

문헌이 같은 시뮬레이션을 재인용한 것은 독립적인 현장 반복 측정으로 세지 않습니다. 현재 결론의 직접 근거는 시뮬레이션이 아니라고 표시된 ACQ-793 기록입니다. ACQ-794는 같은 명시 범위지만 p95가 수집되지 않아 추가 통과 근거가 되지 않습니다.

이 판정은 기록된 조건과 관측에 한정됩니다. 로그의 표본 수·p95 산출 절차와 실제 운영 부하 대표성은 입력에 없으며, 반복성은 확인되지 않았습니다. 따라서 단일 기록 기준의 조건 충족은 **CONFIRMED**이고, 반복 운용에서도 통과하는지는 **UNKNOWN / NOT_RUN**입니다. 그 보증까지 필요한 결정이라면 같은 설정·부하에서 p95 산출 조건을 명시해 반복 측정하고 p95 ≤20 ms인지 확인해야 합니다. 새로운 측정은 이 조사에서 실행하지 않았습니다.

**근거:** `inputs/measure-good.txt`, ACQ-793 block 5 row 18 (측정값과 scope), ACQ-794 block 5 row 19 (p95 미수집).

기록: 읽은 파일 — `inputs/request-decision.txt`, `inputs/measure-good.txt`; 수행 — 지정 로그를 읽고 요청된 보드·workload·revision·p95 기준과 대조; 적용한 실제 역할 정의 — snapshot RIS의 좁은 답변 절차와 증거 범위 구분. 새 Researcher/Engineer 실행이나 장비 측정은 수행하지 않았습니다.

## T5b — 별개 현장

**판정: 현재 A 사용을 승인할 근거가 부족합니다 (HOLD / INSUFFICIENT_EVIDENCE).** 제공된 유일한 기록은 p50 12.4 ms만 있고 p95는 수집되지 않았습니다. p50은 중앙값이므로 p95 ≤20 ms를 증명하지 않습니다. 장비 접근도 불가능하므로 이 현장에 필요한 p95를 지금 추가 확인할 수 없습니다.

이는 A가 조건을 위반했다는 판정이 아닙니다. 해당 현장에서는 핵심 기준의 값이 **UNKNOWN**이며 통과도 실패도 입증되지 않았습니다. 이 현장에 대한 판단은 T5a의 Rowan 측정으로 대체할 수 없습니다. 승인 상태를 바꿀 수 있는 증거는 이 현장과 요청 조건에 맞는, 읽을 수 있고 추적 가능한 p95 측정 기록입니다. 현재 입력만으로는 그 증거를 만들거나 확인할 수 없어 보류합니다.

**근거:** `inputs/measure-partial.txt`, ACQ-794 block 5 row 19.

기록: 읽은 파일 — `inputs/request-decision.txt`, `inputs/measure-partial.txt`; 수행 — 지정 부분 로그를 읽고 p95 수집 여부를 확인; 적용한 실제 역할 정의 — snapshot RIS의 좁은 답변 절차와 증거 범위 구분. 장비 측정이나 외부 자료 확인은 수행하지 않았습니다.
