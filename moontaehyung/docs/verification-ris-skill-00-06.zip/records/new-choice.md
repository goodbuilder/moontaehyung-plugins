## (a) nodoc — D-51 추천

**조건부 추천: B.** `observations/board.txt`의 ACQ-041 r1 행 8은 B가 부하 L에서 p95 18ms였다고 보고해, 계획의 p95 ≤20ms 기준 안에 듭니다. A는 `observations/sim.txt`의 SIM-2 행 a에서 시뮬레이션 p95 15ms지만 장비 실측은 없습니다.

- **A 보류 사유:** 시뮬레이션 수치를 B의 장비 측정과 직접 비교할 수 없습니다. 기록만으로는 revision 일치나 나머지 필수 조건도 확인되지 않습니다.
- **재검토 조건:** 요구된 동일 revision·부하 L 조건에서 B의 18ms와 A의 장비 실측을 비교하고, A가 p95 ≤20ms이면서 B보다 낮고 나머지 필수 조건도 충족하면 추천을 다시 검토합니다.
- **독립 검토:** `NOT_RUN` — 별도 감사자는 배정되지 않았습니다.
- 연구 파일은 수정하지 않았습니다.

## (b) chosen — 사용자 선택 기록

사용자가 D-51에서 **B를 선택**했고, 이유는 측정 지연이 요구 범위 안에 들었기 때문이라고 밝혔습니다. 기존 기록상 ACQ-041 r1 행 8은 B, 부하 L, p95 18ms입니다. 이 기록은 사용자의 선택을 남기며 revision 일치나 나머지 필수 조건을 검증한 것으로 보지 않는다고 명시했습니다. A의 15ms는 시뮬레이션 값으로 구분했고 독립 검토 상태는 `NOT_RUN`으로 적었습니다.

- 수정: `projects/new/chosen/research/plans/choice.md`, `projects/new/chosen/research/CONTEXT.md`
- 두 노트의 기존 바이트는 `.ris/history/`에 preimage 백업으로 보존했습니다.

## (c) fact — board.txt의 보고 수치

**p95 18ms** — `projects/new/fact/observations/board.txt`, ACQ-041 r1 행 8. 별도 저장은 하지 않았습니다.

실행 내역: 변경 파일 — `projects/new/chosen/research/plans/choice.md`, `projects/new/chosen/research/CONTEXT.md`, `records/new-choice.md`; 조치 — RIS 후보 스냅샷의 `ris.py update`를 예상 SHA-256으로 두 노트를 각 2회(총 4회) 갱신하고 각 preimage 백업을 보존; 역할 정의 — 증거 확인은 `candidate/agents/researcher.toml`의 bounded evidence check 범위, 기록 통합은 RIS Coordinator( `candidate/skills/ris/references/role-workflow.md` ); managed-note check PASS (3 notes, no errors/warnings); 별도 감사자/위임 작업은 없음.
