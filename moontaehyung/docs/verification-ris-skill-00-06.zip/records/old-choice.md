## 결과

### (a) nodoc — D-51 추천

B를 잠정 추천합니다. `ACQ-041 r1` 행 8은 목표 장비 B가 부하 L에서 p95 18ms라고 보고하며, D-51의 한계는 p95 ≤20ms입니다. A의 `SIM-2` p95 15ms는 시뮬레이션 값이고 장비 실측이 없어 B 측정치와 직접 비교할 수 없습니다. 근거는 [nodoc 관측 자료](../projects/old/nodoc/observations/board.txt), 목표는 [nodoc 계획](../projects/old/nodoc/research/plans/choice.md)입니다.

보류 사유는 현재 자료에서 B 측정의 목표 revision 일치와 나머지 필수 조건 충족을 확인할 수 없다는 점입니다. 같은 revision·부하의 확인에서 B가 20ms를 넘거나 다른 필수 조건을 위반하면 추천을 뒤집어야 합니다. 별도 감사자는 배정되지 않았고 독립 검토는 수행되지 않았습니다. nodoc 연구 파일은 수정하지 않았습니다.

### (b) chosen — B 선택 기록

기존 기록에 B 선택과 사용자가 밝힌 이유를 반영했습니다. [계획](../projects/old/chosen/research/plans/choice.md)에는 `ACQ-041 r1` 행 8의 B·부하 L·p95 18ms를 D-51 기준 p95 ≤20ms와 함께 기록하고, 이것이 사용자 선택의 근거임을 남겼습니다. 같은 revision 및 나머지 필수 조건은 이 관측으로 검증됐다고 간주하지 않는다고 명시했습니다. [현재 맥락](../projects/old/chosen/research/CONTEXT.md)과 [인계](../projects/old/chosen/HANDOFF.md)도 선택 후 상태에 맞췄고, 이전의 “미선택” 상태는 superseded 이력으로 보존했습니다.

`ris.py check` 결과 오류와 경고 없이 통과했습니다. 별도 감사자는 배정되지 않았습니다. 허용된 old 플러그인 스냅샷에는 Archify 렌더러가 없어 HTML 계획·지도는 생성하지 못했으며, 이 제한을 인계에 기록했습니다.

### (c) fact — board.txt의 숫자

p95 18ms — 출처: [fact 관측 자료](../projects/old/fact/observations/board.txt), `ACQ-041 r1`. 기록은 저장하지 않았습니다.

실행 파일/행위: 읽기 — `/tmp/ris-skill-work-20261123-d6wegE/inputs/request-choice.txt`, `old/skills/ris/SKILL.md`, `old/agents/researcher.toml`, 관련 RIS 탐색·공유 출력 지침 및 Project Plan 참조, `projects/old/nodoc`의 지정 연구 자료, `projects/old/chosen`의 지정 연구 자료와 `.ris/project.yaml`, `projects/old/fact/observations/board.txt`; 쓰기 — chosen의 `research/plans/choice.md`, `research/CONTEXT.md`, `HANDOFF.md`, RIS helper가 만든 `.ris/history` preimages, 이 harness 파일; 수행 — `ris.py update`, `ris.py check`(PASS, errors=0, warnings=0), HANDOFF 갱신. 네트워크·위임·nodoc/fact 프로젝트 쓰기는 없었음. `git diff`는 harness 경로가 Git 저장소가 아니어서 실행되지 않음. 실제 사용한 역할 정의: `old/agents/researcher.toml`의 RIS Researcher(책임: evidence·대안·coverage 조사; canonical 결정 그래프 소유·감사 권한 없음; 정의된 모델 `gpt-6.1-sol`, medium).
