표 2, 행 c에서 관측 대상은 Larch-1 시뮬레이터(배치 4)이며, p95 지연시간은 15밀리초(ms)입니다.

근거: `inputs/table.md`, 표 2, 행 c. 요청에 지정된 파일만 확인했습니다.

작업 기록: 확인한 파일 — `guide.txt`, `inputs/request-narrow.txt`, `phase12/agents/researcher.toml`, `phase12/skills/ris/SKILL.md`, `inputs/table.md`; 명령/행동 — `cat`, `rg --files`, `ls`로 지정 지침·요청·역할 정의·표를 확인하고 이 답변을 기록함; 실제 역할 정의 — `phase12/agents/researcher.toml`의 RIS Researcher, bounded evidence check.
