## (a) nodoc — D-51 추천

**추천:** B, p95 기준의 조건부 추천입니다. `observations/board.txt`의 ACQ-041 r1 행 8은 목표 장비 B와 부하 L에서 p95 18ms를 보고하며, 계획의 p95 한도 20ms 이내입니다. A의 SIM-2 행 a는 p95 15ms지만 시뮬레이션이고 장비 실측이 없어 실제 장비 적격 근거로 삼기 어렵습니다. 나머지 필수 조건과 관측의 동일 revision 일치는 기록에서 확인되지 않아 전체 적격 판정은 아닙니다. 동일 revision·부하에서 B가 p95 한도를 넘거나 다른 필수 조건을 충족하지 못하는 경우, 또는 A가 비교 가능한 장비 실측으로 p95 및 나머지 필수 조건을 충족하는 경우 추천을 다시 검토해야 합니다. 별도 감사자는 배정되지 않았으며 독립 검토는 수행되지 않았습니다.

실행: `nodoc`의 `HANDOFF.md`, `.ris/project.yaml`, `research/INDEX.md`, `research/CONTEXT.md`, `research/plans/choice.md`, `observations/{board,label,sim}.txt`를 읽었습니다. 연구 파일 쓰기는 없었습니다. 역할 정의: RIS Researcher — `final/agents/researcher.toml`의 제한된 근거 확인 역할과 `final/skills/ris/SKILL.md`를 적용했습니다.

## (b) chosen — 사용자 선택 기록

사용자가 D-51에서 B를 선택한 사실과 이유(측정 p95 지연이 요구 범위 안에 듦)를 기존 계획에 기록했습니다. 근거는 `observations/board.txt`의 ACQ-041 r1 행 8(B, 부하 L, p95 18ms)이며, 계획 한도는 p95 ≤20ms입니다. 나머지 필수 조건과 동일 revision 조건은 이 관측만으로 확인되지 않았고, 별도 감사자가 없어 독립 검토도 수행하지 않았다고 함께 남겼습니다. `research/CONTEXT.md`도 현재 선택과 미해결 조건에 맞게 갱신했습니다. helper가 두 원본의 preimage를 `.ris/history/`에 보존했습니다. `ris.py check` 결과는 `ok: true`, 오류 0, 경고 0입니다.

실행: `research/plans/choice.md`, `research/CONTEXT.md`를 hash-guarded `ris.py update`로 갱신하고 `ris.py check`를 실행했습니다. 역할 정의: 선택 기록은 RIS Coordinator — `final/templates/ris-coordinator-AGENTS.md` 및 `final/skills/project-plan/SKILL.md`; 근거 구분은 RIS Researcher — `final/agents/researcher.toml` 및 `final/skills/ris/SKILL.md`를 적용했습니다.

## (c) fact — 요청한 숫자

p95 **18 ms**. 출처: `fact/observations/board.txt` — ACQ-041 r1, 행 8.

실행: `fact` 프로젝트의 `HANDOFF.md`, `.ris/project.yaml`, `research/{INDEX,CONTEXT,plans/choice.md}`와 `observations/board.txt`를 읽었고, 출력 숫자는 board만 근거로 삼았습니다. 저장하지 않았습니다. 역할 정의: RIS Researcher — `final/agents/researcher.toml`의 제한된 사실 확인 역할과 `final/skills/ris/SKILL.md`를 적용했습니다.
