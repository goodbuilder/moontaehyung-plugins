# T4

**판정: 현재 자료로는 A와 B 중 어느 주장도 지지할 수 없습니다.** 배치 크기 32에서 두 대안이 모두 110 ms였다는 관측 하나로는 고정 설정 시간과 항목당 처리 시간의 효과를 분리할 수 없습니다. 기준선 측정도 없어 A나 B가 실제로 시간을 줄였는지도 확인되지 않았습니다.

Engineer 역할에 따라 다음 검증은 `T(n) = setup + n × per-item`을 기준으로 두 효과를 따로 측정해야 합니다. 기준선, A, B를 같은 기계와 입력 설정에서 비교하고, 32보다 작은 크기와 큰 크기를 포함해 허용된 여러 배치 크기를 시험합니다. 파일럿으로 기준 측정과 간섭 여부를 확인한 뒤, 간섭이 없다면 같은 조건끼리 짝지어 순서를 균형화해 반복 측정합니다. A는 기준선보다 setup 항이 감소하고 per-item 항은 사전 합의한 동등성 범위 안에 있을 때, B는 per-item 항이 감소하고 setup 항은 그 범위 안에 있을 때 각각의 주장을 지지할 수 있습니다. 실용적 차이와 동등성의 수치 기준은 주어지지 않아 시험 전에 정해야 합니다.

Planner 역할에 따라 파일럿을 먼저 두고 그 결과로 본 비교를 진행한 뒤, 계수별 결과를 대안 선택 전에 연결합니다. A의 setup 효과만 확인되면 A 주장을, B의 per-item 효과만 확인되면 B 주장을 지지합니다. 둘 다 확인되거나 둘 다 확인되지 않으면 해당 결과대로 판단하고, 측정 불확실성 때문에 구분되지 않으면 `UNKNOWN`으로 남깁니다. 채택 결정 전에는 선택한 대안을 의도한 단독 설정에서도 확인해야 합니다. 현재 1개 배치 크기의 관측은 이 판단을 바꾸지 않습니다.

추적: 읽은 파일은 `inputs/request-decision.txt`, `inputs/two-models.txt`, `old/skills/ris/SKILL.md`, `old/skills/ris/references/role-workflow.md`, `old/agents/engineer.toml`, `old/agents/planner.toml`입니다. `cat`과 `rg --files`로 읽기 전용 확인 후 이 기록을 작성했습니다. 실험은 실행하지 않았습니다. 실제 적용한 역할 정의: Engineer 및 Planner.

# T5a — Rowan / workload K / revision 9

**판정: 측정 기록이 A의 결과라는 전제 아래, 기록된 조건에서는 기준을 통과합니다. 더 넓은 사용 범위에 대한 확정 판정은 아닙니다.** ACQ-793은 Rowan, workload K, required revision 9에서 p95 18.6 ms를 기록했습니다. 이는 20 ms 기준보다 1.4 ms 낮고, `simulation=false`로 표시되어 있습니다. 다만 파일 자체에는 이 기록과 대안 A의 연결이 명시되어 있지 않습니다. 그 연결이 확인되지 않으면 A에 대한 판정은 아직 성립하지 않습니다.

기록 한 건에는 p95 산출법, 표본 수, 반복 간 변동 정보가 없습니다. 따라서 현재 확인되는 것은 이 로그의 p95 값뿐이며, 다른 실행이나 운용 조건에서도 기준을 만족한다는 보장은 아닙니다. 같은 시뮬레이션 결과를 재인용한 문헌은 그 설명대로라면 독립적인 실기기 측정 근거가 아닙니다. 제공된 자료에 문헌의 식별 정보와 원문은 없고 네트워크 접근도 금지되어 있어 문헌 자체는 확인하지 않았습니다. 이번 평가는 제공된 계측 기록에 한정됩니다.

따라서 A가 ACQ-793에 대응하고 이 로그의 p95 정의가 요구 기준과 일치한다면, 명시된 Rowan/K/revision 9 조건에서의 사용은 조건부로 지지됩니다. 그 전제 또는 다른 실행까지 포함하는 신뢰성이 요구된다면 판정은 보류하고, A와 로그의 연결 및 측정 프로토콜·표본 범위를 확인해야 합니다.

추적: 읽은 파일은 `inputs/request-decision.txt`, `inputs/measure-good.txt`, `old/skills/ris/SKILL.md`, `old/skills/ris/references/role-workflow.md`, `old/skills/ris/references/research-exploration.md`, `old/agents/researcher.toml`, `old/agents/engineer.toml`입니다. `cat`과 `rg --files`로 제공 자료를 읽었습니다. 외부 검색, 문헌 원문 확인, 장비 시험은 하지 않았습니다. 실제 적용한 역할 정의: Researcher(증거 범위), Engineer(기준·검증 조건); 전체 다중 출처 연구는 오프라인 범위 제한으로 `NOT_RUN`입니다.

# T5b — 별개 현장 / Rowan / workload K / revision 9

**판정: `HOLD / INSUFFICIENT_EVIDENCE` — p95 ≤20 ms 기준을 충족한다고 판정할 수 없습니다.** 이 별개 현장에서 제공된 ACQ-794 기록은 Rowan, workload K, required revision 9의 p50 12.4 ms만 보고하며 p95는 수집되지 않았습니다. p50만으로 p95를 추론하거나 상한을 보장할 수 없습니다. `simulation=false` 표기는 p95 값의 부재를 보완하지 않습니다.

장비 접근이 불가능하고 지정된 유일 자료에 p95가 없으므로 현재 허용된 범위에서 이 불확실성을 해소할 근거가 없습니다. 이는 A가 기준에 실패했다는 뜻이 아니라 통과 여부가 미확인이라는 뜻입니다. 이 현장의 판정에는 다른 요청의 측정 결과를 가져오지 않았습니다. 정확한 장비·workload·revision에서 A에 연결되는 p95 기록과 그 산출 범위를 확인할 수 있을 때 재판정할 수 있습니다. 그 전에는 p95 기준을 전제로 한 사용 적합 판정을 내릴 수 없습니다.

추적: 읽은 파일은 `inputs/request-decision.txt`, `inputs/measure-partial.txt`, `old/skills/ris/SKILL.md`, `old/skills/ris/references/role-workflow.md`, `old/skills/ris/references/research-exploration.md`, `old/agents/researcher.toml`, `old/agents/engineer.toml`입니다. `cat`과 `rg --files`로 제공 자료를 읽었습니다. 외부 검색과 장비 시험은 하지 않았습니다. 실제 적용한 역할 정의: Researcher(증거 범위), Engineer(기준·검증 조건); 장비 접근 불가와 자료 범위 때문에 추가 검증은 `BLOCKED`입니다.
