모드: 좁은 사실 확인(Narrow answer).

두 발췌문 사이에 CLI 옵션 불일치가 있습니다. `cli.py` 파서는 `--format` 값으로 `text` 또는 `json`만 허용하지만 README는 `ris --format csv`를 안내합니다. 따라서 README 명령은 파서의 허용 값과 맞지 않아 현재 설명대로라면 파서에서 거부됩니다. 요청대로 읽기만 했으므로 실행 검증은 하지 않았습니다.

기록: `/tmp/ris-skill-work-20261123-d6wegE/records/old-router2.md`; 읽은 파일: `guide.txt`, `old/skills/ris/SKILL.md`, `inputs/request-router2.txt`, `inputs/route-app.txt`; 행위: 지정 자료 읽기만 수행, 명령 실행·파일 수정·테스트 없음(기록 파일 제외); 적용 역할 정의: RIS SKILL의 “Narrow answer or meta question”, 별도 에이전트 정의 미사용.
