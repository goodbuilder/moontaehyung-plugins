# 승인 스냅샷 오프라인 스킬 스모크 — 원답

## 사례 1 — 학교 기록 복구 아카이브

독립 표본은 부록 P §1, §3의 E1과 E2입니다. 두 아카이브 세트는 새로, 서로 독립적으로 표집되었고 같은 복구 기준에서 둘 다 복구되었습니다. 사무실 메모 V ¶2는 P §1의 E1 표를 다시 싣는 자료이므로 새로운 독립 표본이나 별도의 재현 결과로 세면 안 됩니다.

구성별로는 P §5가 같은 사용자 프로토콜에서 Terra의 유효 복구(3.8일)와 Mora의 유효 복구(2.1일)를 보고합니다. 두 시간 모두 4일 이내이므로, 질문에 주어진 다른 필수 조건도 충족한다는 전제에서 Terra와 Mora 모두 기준을 통과합니다. 더 짧은 시간을 선호한다는 기준이 없으므로 Mora를 우선하거나 하나를 선택할 근거는 없습니다. 자료는 각 구성 결과를 E1 또는 E2에 대응시키지 않으므로 그런 짝을 추정하지 않습니다.

추적: 읽은 파일 — `guide.txt`, `accepted/skills/ris/SKILL.md`, `accepted/agents/researcher.toml`, `inputs/request-archive.txt`, `inputs/holdout-archive.txt`. 수행 — 요청과 지정 자료만 읽고 표본 독립성, 재게시 여부, 제시된 시간과 4일 기준을 대조함. 사용 역할 — RIS Researcher; `researcher.toml`의 bounded evidence check 정의에 따라 지정 자료에서 finding, locator, applicability, material gap을 반환.

## 사례 2 — Rowan / workload K / revision 9 측정

ACQ-793 블록 5, 행 18(영수증 토큰 `xy39`)에는 Rowan, workload K, required revision 9, `simulation=false`, p95 18.6 ms가 기록되어 있습니다. 따라서 제공된 행의 수치 자체는 20 ms 이하입니다(18.6 ≤ 20). p50 11.3 ms는 p95 기준 판정에 쓰지 않습니다.

다만 이 행에는 후보 A라는 식별자가 없습니다. 그러므로 현재 자료만으로는 18.6 ms를 후보 A에 귀속할 수 없어, **후보 A가 기준을 통과했다고 확정할 수 없습니다**. 필요한 다음 확인은 토큰 `xy39` 또는 그 원 acquisition 기록으로 이 행이 후보 A의 실제 구성에 해당하는지 확인하는 것입니다. 귀속과 revision이 확인되면 이 측정의 p95는 기준을 통과합니다. 원자료에 p95 산출 창·표본 수 같은 유효성 정보가 별도 정의되어 있다면 해당 측정이 그 정의를 충족하는지도 확인해야 합니다.

추적: 읽은 파일 — `guide.txt`, `accepted/skills/ris/SKILL.md`, `accepted/agents/researcher.toml`, `inputs/request-solo-untagged.txt`, `inputs/measure-good.txt`. 수행 — 요청과 지정 로그만 읽고 장비·workload·revision·simulation 상태·p95를 대조했으며, 로그에 없는 후보 식별은 미확인으로 남김. 사용 역할 — RIS Researcher; `researcher.toml`의 bounded evidence check 정의에 따라 지정 자료에서 finding, locator, applicability, material gap을 반환.
