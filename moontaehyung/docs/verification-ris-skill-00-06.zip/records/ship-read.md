Case nodoc: no project research files written.
Case fact: no project research files written; no project save requested.
No separate reviewer or delegated agent was used.

Exact files opened:
- /tmp/ris-skill-work-20261123-d6wegE/ship/skills/ris/SKILL.md
- /tmp/ris-skill-work-20261123-d6wegE/ship/skills/ris/references/research-exploration.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/nodoc/.ris/project.yaml
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/nodoc/research/INDEX.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/nodoc/research/CONTEXT.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/nodoc/HANDOFF.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/nodoc/research/plans/choice.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/nodoc/observations/board.txt
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/nodoc/observations/sim.txt
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/fact/.ris/project.yaml
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/fact/research/INDEX.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/fact/research/CONTEXT.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/fact/HANDOFF.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/fact/research/plans/choice.md
- /tmp/ris-skill-work-20261123-d6wegE/projects/ship/fact/observations/board.txt
