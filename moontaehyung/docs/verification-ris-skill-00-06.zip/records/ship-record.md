# Ship record — D-51 사용자 선택 기록

일자: 2026-11-23

## 요청과 결과
진행 중인 D-51에서 사용자가 B를 선택했고, 측정 지연이 요구 범위 안에 든 점이 이유라고 밝혔다. 이 선택과 이유를 지정된 임시 프로젝트의 기존 연구 기록에 반영했다.

## 확인한 기존 상태
- `research/plans/choice.md`에는 D-51의 기준 p95 ≤20ms와 나머지 필수 조건이 있었고, 사용자 선택은 아직 기록되지 않았다.
- `observations/board.txt`의 ACQ-041 r1 행 8은 장비 B, 부하 L, p95 18ms를 기록한다. 18ms는 p95 기준 안에 든다.
- 관측에는 요구된 동일 revision 여부가 명시되어 있지 않고, 나머지 필수 조건의 확인 기록도 보이지 않았다. 기존 `sim.txt`의 A 결과는 p95 15ms 시뮬레이션이며 장비 실측이 아니다.
- 변경 전 RIS `check`: `ok: true`, 오류·경고 없음.

## 실제 변경
- `projects/ship/chosen/research/plans/choice.md`: 2026-11-23 사용자 선택 B와 이유를 기록하고, 선택 자체가 모든 요구조건 검증 완료를 뜻하지 않는다고 명시.
- `projects/ship/chosen/research/CONTEXT.md`: 현재 판단·근거·미확인 조건·다음 행동을 갱신. A의 시뮬레이션 기록과 D-52의 별도 범위를 유지.
- `projects/ship/chosen/HANDOFF.md`: 현재 선택, 정본 계획 링크, 남은 조건 확인 작업을 갱신.
- RIS helper의 hash-guarded update로 계획과 맥락을 수정하고 원본 백업을 `.ris/history/`에 보존했다. HANDOFF도 읽은 preimage hash를 확인하고 `.ris/history/`에 원본을 보존한 뒤 갱신했다. INDEX는 이미 계획과 맥락을 링크하고 있어 수정하지 않았다.

## 확인 결과와 범위
- 변경 후 RIS `check`: `ok: true`, 오류·경고 없음.
- 계획, 맥락, 인계 노트를 다시 읽었고, 세 원본 백업의 SHA-256이 각 preimage와 일치함을 확인했다.
- 사용자 선택 기록만 수행했다. 추가 연구, 별도 감사, 위임, 테스트, HTML 생성은 수행하지 않았다.
- 다음 작업은 B 측정의 동일 revision 여부와 나머지 필수 조건의 근거를 확인하는 것이다. 이번 기록은 그 조건들의 충족을 주장하지 않는다.
