# Independent audit — `records/old-choice.md`

## Verdict: FAIL (one low-severity, correctable scope/evidence finding)

The substantive D-51 claims and the fact-only answer match the inspected source notes. The chosen-project handoff also contains an unrelated renderer-status assertion that was outside the requested record update and is unsupported by the allowed project materials reviewed here. This is a small record-integrity issue; it does not invalidate the B selection record or the reported latency.

## Inspected scope and evidence

- Audit instructions: `old/agents/auditor.toml`; `old/skills/research-audit/SKILL.md`; `old/skills/research-audit/references/audit-contract.md`.
- Request and completed answer: `inputs/request-choice.txt:1`; `records/old-choice.md:3-19`.
- `nodoc`: active D-51 requirements in `projects/old/nodoc/research/plans/choice.md:11-17`; measurement in `projects/old/nodoc/observations/board.txt:1`; A comparison caveat in `projects/old/nodoc/observations/sim.txt:1`. The current context and plan still show no user choice.
- `chosen`: current requirements and selection record in `projects/old/chosen/research/plans/choice.md:11-25`; current understanding and unresolved conditions in `projects/old/chosen/research/CONTEXT.md:11-35`; handoff in `projects/old/chosen/HANDOFF.md:5-11`; source measurement in `projects/old/chosen/observations/board.txt:1`. The `.ris/history/` preimages preserve the earlier unselected plan and blank context.
- `fact`: `projects/old/fact/observations/board.txt:1`.
- Independently reran the read-only checker using `/usr/bin/python3 -B old/skills/ris/scripts/ris.py --project projects/old/chosen check`: `ok=true`, 3 notes, 0 errors, 0 warnings. This confirms the current state; no historical command log was supplied.

## Response-by-response assessment

### (a) `nodoc` recommendation

**PASS.** The answer attributes B's p95 18 ms to `ACQ-041 r1`, row 8, and compares it with the plan's `p95 ≤20 ms` requirement. It correctly treats A's p95 15 ms as simulation-only (`SIM-2`, row a), so it does not claim a like-for-like comparison. It makes B provisional, states that target-revision alignment and other mandatory conditions remain unconfirmed, and gives a valid reversal condition. The current nodoc plan remains unselected, consistent with the reported no-write scope; however, no before/after snapshot or write log was available to prove the historical no-write claim.

### (b) `chosen` selection record

**Substantive content passes; finding A-001 applies.** The user-selected B and stated reason are recorded. The plan and context preserve the distinction between the observed `18 ms ≤20 ms` result and the still-unverified target revision and other required conditions. The earlier unselected state is present in history preimages, and the handoff reflects that a user response is no longer needed while D-51 validation remains open. The checker was independently rerun successfully as noted above.

The answer's `ris.py check` result is consistent with the independent rerun, but its exact historical execution is not independently established without the original command output. The claim that an old plugin snapshot lacked an Archify renderer is not supported by the reviewed project sources and was not independently checked.

### (c) `fact` number and source

**PASS.** `p95 18 ms` is the only measurement value in `projects/old/fact/observations/board.txt:1`; it is attributed to that file and `ACQ-041 r1`. No numeric claim was imported from the label or simulation notes. The response says it was not saved, consistent with the request; current project files show no added research record, though no write-history evidence was supplied.

## Material finding

```yaml
id: A-001
severity: low
scope: evidence
reference: records/old-choice.md:13; projects/old/chosen/HANDOFF.md:11
evidence: "The chosen request asks to record B and the user's reason. The answer additionally reports that HTML plans/maps were not generated because an old plugin snapshot lacked an Archify renderer, and the handoff stores the same assertion. No reviewed project source establishes renderer availability or makes HTML rendering part of D-51."
impact: "An unrelated, unverified tool-availability assertion has entered the canonical handoff, where it can be mistaken for a project constraint or an outstanding D-51 requirement."
required_correction: "Remove the HTML-renderer sentence from the user-facing answer and chosen HANDOFF; retain it only if a separately requested rendering task supplies direct evidence that makes the limitation relevant."
owner: coordinator
re_audit: "Confirm the unrelated renderer sentence is absent from the answer and chosen HANDOFF, or inspect the cited tool snapshot if the user requests that status be retained."
residual_uncertainty: "The renderer's availability and whether an HTML-generation attempt occurred were not inspected. No project files were changed during this audit."
```

## Audit limits

No network access, peer results, delegation, or project writes were used. The audit did not inspect execution logs, plugin inventory, or a baseline snapshot that could prove historical no-write/no-save behavior. The exact board-file locators are line 1 and embedded source row 8 for `ACQ-041 r1`; `records/old-choice.md:17` cites the source record ID but omits the embedded row number, which remains unambiguous because the board file contains one line.
