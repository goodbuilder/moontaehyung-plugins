## 정정 영향 재평가

재검토할 것은 Paper L의 `+8`과 Paper M의 `+7`입니다. 두 분석은 모두 register X와 group 2를 control로 분류한 동일한 grouping에 의존합니다. register X 관리자의 정정에 따르면 group 2에는 두 처치가 섞여 있었으므로, 이 그룹을 control로 둔 분석은 유효한 비교로 간주할 수 없습니다. M은 X를 같은 grouping으로 재분석한 것이어서 L과 독립적인 확인 결과도 아닙니다.

정정된 outcome이 없으므로 L·M의 추정치와 그에 기대고 있던 추천은 보류하고 다시 분석해야 합니다. 이 자료만으로 효과가 사라졌거나 반대 방향이라고 결론 내릴 수는 없습니다. 세 논문을 합쳐 만든 수치나 “세 연구가 같은 결론을 독립적으로 확인했다”는 종합 주장도 X 기반 결과를 재검토한 뒤 다시 평가해야 합니다.

유지할 수 있는 결과는 Paper N의 `+3`입니다. N은 다른 학교의 register Y를 사용했고 X나 X의 분류를 사용하지 않았으므로, 이번 정정은 N의 분석을 직접 바꾸지 않습니다. 다만 유지 범위는 N이 보고한 해당 학교의 지역 모집단 결과입니다. 이것만으로 더 넓은 모집단의 효과나 L·M의 결과를 확정할 수는 없습니다.

다음 판단에 필요한 자료는 group 2의 혼합 처치를 반영한 register X의 수정 outcome 및 그에 따른 재분석입니다. 이번 평가는 제공된 `inputs/pooled.txt`의 L §3, M §2, N §5, register X 관리자의 §1 정정만 사용했습니다. 별도 이전 종합 기록은 제공 자료에 포함되지 않아, 이 세 논문의 결과에 의존하는 종합 주장보다 넓은 주장은 판정하지 않았습니다.

하네스 기록: 확인 파일 `guide.txt`, `revised/skills/ris/SKILL.md`, `revised/skills/ris/references/research-exploration.md`의 정정 절차, `inputs/request-transfer.txt`, `inputs/pooled.txt`; 조치: X에 의존하는 주장과 독립적인 N 결과를 추적·재평가해 이 파일에 기록, 외부 조회 및 연구 프로젝트 파일 변경 없음; 적용 역할 정의: 별도 custom agent 역할은 할당되지 않아 사용하지 않았고 RIS 기본 스킬의 정정 절차를 적용.
