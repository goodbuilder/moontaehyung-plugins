# Independent audit — `request-choice`

**Status: PASS**

## Scope inspected

- Original request: `inputs/request-choice.txt`.
- Completed response: `records/final-choice.md`.
- Auditor assignment and status/finding contract: `final/agents/auditor.toml`, `final/skills/research-audit/SKILL.md`, and `final/skills/research-audit/references/audit-contract.md`.
- Researcher/Coordinator attribution: `final/agents/researcher.toml`, `final/skills/ris/SKILL.md`, `final/templates/ris-coordinator-AGENTS.md`, and `final/skills/project-plan/SKILL.md`.
- Current source and result state in `projects/confirm/{nodoc,chosen,fact}`: each `HANDOFF.md`, `research/CONTEXT.md`, `research/INDEX.md`, `research/plans/choice.md`, `observations/{board,label,sim}.txt`, `.ris/project.yaml`, and available `.ris/history` entries.

## Findings

No material findings.

- **(a) `nodoc`:** The request asks for a recommendation without writing research files, with evidence, hold reasons, reversal conditions, and independent-review status (`inputs/request-choice.txt:1`). The answer recommends B only on p95 and expressly says that overall eligibility is unconfirmed (`records/final-choice.md:1-5`). This matches the plan’s p95 ≤20ms, same-revision, and remaining-required-conditions criteria (`projects/confirm/nodoc/research/plans/choice.md:11-17`) and the evidence: B at load L, p95 18ms (`observations/board.txt:1`); A at p95 15ms is simulation-only with no device measurement (`observations/sim.txt:1`). The stated hold and reversal conditions preserve those gaps. The project snapshot still has no recorded selection (`research/plans/choice.md:13`) and no substantive research conclusion in CONTEXT (`research/CONTEXT.md:11-27`).
- **(b) `chosen`:** The user’s selection and rationale are recorded as user decisions in the plan (`projects/confirm/chosen/research/plans/choice.md:13-17`) and summarized in CONTEXT (`research/CONTEXT.md:18-29`). The board value is correctly tied to B/load L/p95 18ms (`observations/board.txt:1`), and the answer does not claim that this alone proves same-revision or other required conditions (`records/final-choice.md:7-11`). The available history contains the exact prior plan and context preimages, consistent with preserving the earlier state. I reran the snapshot’s `ris.py --project projects/confirm/chosen check`: `ok: true`, zero errors and zero warnings.
- **(c) `fact`:** The response gives only p95 18ms and attributes it to `fact/observations/board.txt`, ACQ-041 r1 row 8 (`records/final-choice.md:13-17`; `projects/confirm/fact/observations/board.txt:1`). It adds no unsupported numeric claim.
- **Attribution and review status:** The bounded evidence lookups are attributed to the Researcher, while the user-selected canonical-plan update is attributed to the Coordinator, with evidence qualification attributed to the Researcher (`records/final-choice.md:5,11,17`). Those roles match the inspected definitions. The original request says no separate Auditor was assigned; the answer therefore correctly reports that independent review was not performed rather than implying its own work was an earlier audit.
- **Writes and handoffs:** In the supplied final-state snapshot, `nodoc` and `fact` retain their initial-looking, unselected research notes and have no note preimage entries; their HANDOFF files contain only the plan pointer. The `chosen` updates are confined to its plan and CONTEXT, with their prior note bytes retained in `.ris/history`; its HANDOFF likewise remains the plan pointer. No handoff change is represented or claimed in the answer. This is consistent with the requested write boundary and the authorized recording for `chosen`.

## Scope limits

The assigned artifacts contain no execution transcript for the original hash-guarded update or a pre-run file manifest for `nodoc` and `fact`. I verified the recorded final state and independently reran the read-only structural check for `chosen`; transient write-and-revert behavior cannot be established from those artifacts. No external sources, other projects, or network material were used.
