# 외부 하네스 수신 기록 — D-51

**추천:** B를 잠정 추천한다. 관측은 목표 장비 B에서 부하 L의 p95가 18ms라고 보고해 20ms 기준 안에 든다. A의 15ms는 시뮬레이션 값이라 장비 실측 요건을 입증하지 않는다. [관측: `projects/explicit/nodoc/observations/board.txt:1`; A 시뮬레이션: `projects/explicit/nodoc/observations/sim.txt:1`; 기준: `projects/explicit/nodoc/research/plans/choice.md:13`]

**보류 사유:** 기준은 동일 장비 revision의 측정을 요구하지만 B 관측에는 장비 revision이 적혀 있지 않아 그 일치 여부는 미확인이다. 나머지 필수 조건은 A와 B 모두 충족했다고 사용자가 확인한 상태이며, 독립 검토 기록은 없다. [조건·검토 상태: `projects/explicit/nodoc/research/plans/choice.md:14`]

**뒤집히는 조건:** B 측정이 다른 revision에서 나온 것으로 확인되거나 동일 revision 측정이 20ms를 넘으면 B 추천을 철회한다. A가 목표 장비·부하 L·동일 revision에서 실측되고 p95가 B의 유효한 18ms보다 낮으면 A로 바꾼다. 현재 A와 B 수치는 시뮬레이션과 장비 측정이라 직접 비교할 수 없다. [조건: `projects/explicit/nodoc/research/plans/choice.md:13`; B 관측: `projects/explicit/nodoc/observations/board.txt:1`; A 관측: `projects/explicit/nodoc/observations/sim.txt:1`]

**독립 검토:** 수행하지 않음. 프로젝트 기록에도 독립 검토가 없다고 명시되어 있다. [`projects/explicit/nodoc/research/plans/choice.md:14`]
