# D-51 요청 응답 및 실행 흔적

세 요청은 서로 다른 프로젝트 사례로 처리했다. 제공된 `release/` 스냅샷만 사용했고 네트워크 검색이나 위임은 하지 않았다.

## (a) nodoc — 추천만

**모드: D-51 범위의 조건부 추천; 연구 파일은 수정하지 않았습니다.**

B를 우선 추천합니다. `observations/board.txt`의 ACQ-041 r1 행 8은 목표 장비 B와 동일 부하 L에서 p95 18ms를 보고하며, 계획의 p95 ≤20ms 기준 안입니다. A의 p95 15ms는 SIM-2 시뮬레이션이고 장비 실측은 없어 B와 같은 조건의 실측 비교가 아닙니다. A는 동일 revision·부하에서 실제 측정하고 나머지 필수 조건도 충족함을 확인할 때까지 보류합니다. 현재 자료는 ACQ-041 r1과 목표 revision의 정확한 일치 및 나머지 필수 조건을 입증하지 않으므로, B의 추천은 그 확인을 전제로 합니다. B의 같은 조건 측정이 20ms를 넘거나 필수 조건에 실패하면 재검토하고, A의 비교 가능한 실측이 B보다 낮은 p95로 기준을 충족하면 순위를 다시 검토합니다. 별도 감사자가 배정되지 않았고 독립 검토는 수행되지 않았습니다.

**실행 흔적:** 읽음 — `projects/accept/nodoc/.ris/project.yaml`, `research/INDEX.md`, `research/CONTEXT.md`, `research/plans/choice.md`, `HANDOFF.md`, `observations/board.txt`, `observations/label.txt`, `observations/sim.txt`; 판단에 사용 — D-51 계획, board.txt, sim.txt; D-52 라벨 내용은 판단에서 제외. 동작 — `cat` 읽기만, 프로젝트 파일 쓰기 없음. 역할 — `release/agents/researcher.toml`의 RIS Researcher (gpt-6.1-sol/medium; 근거·대안 확인, 결정 확정 및 독립 감사 주장 금지), `release/skills/ris/SKILL.md`의 추천·근거 기준.

## (b) chosen — 사용자 선택 기록

기록했습니다. D-51에서 사용자가 B를 선택했고, 이유는 측정 지연이 요구 범위 안에 든다는 것이라고 남겼습니다. `observations/board.txt`의 ACQ-041 r1 행 8은 B·동일 부하 L에서 p95 18ms를 보고합니다. 계획의 이력과 현재 맥락을 갱신했으며, 이 기록은 사용자 선택을 적은 것이지 독립 검토나 전체 필수조건 인수 판정이 아닙니다. 목표 revision 일치와 나머지 필수 조건의 항목별 근거는 현재 자료에서 명시적으로 확인되지 않았고, 별도 감사자는 배정되지 않았습니다. D-52는 별도 상태로 유지했습니다.

**실행 흔적:** 읽음 — `projects/accept/chosen/.ris/project.yaml`, `research/INDEX.md`, `research/CONTEXT.md`, `research/plans/choice.md`, `HANDOFF.md`, `observations/board.txt`, `observations/label.txt`, `observations/sim.txt`. 수정 — `research/plans/choice.md`, `research/CONTEXT.md`는 스냅샷의 `ris.py update`를 기대 해시와 함께 사용했고, 기존 바이트를 `.ris/history/`에 보존; `HANDOFF.md`는 `.ris/write.lock` 잠금 및 해시 확인 후 갱신하고 preimage를 보존. 첫 HANDOFF 시도는 잘못 입력한 기대 해시와 불일치하여 거부됐으며 쓰기는 없었고, 재확인한 해시로 갱신을 완료했습니다. 검증 — 스냅샷 `ris.py --project projects/accept/chosen check`: `ok: true`, errors 0, warnings 0. 역할 — `release/agents/researcher.toml`의 RIS Researcher; 기록 경계는 `release/skills/ris/SKILL.md` 및 `references/operations.md`, 결정 기록은 `release/skills/project-plan/SKILL.md`의 사용자 결정·이력 보존 기준을 적용했습니다.

## (c) fact — board 수치만

**18ms (p95)** — 출처: `observations/board.txt`, ACQ-041 r1 행 8.

**실행 흔적:** 답의 수치 근거 — `projects/accept/fact/observations/board.txt`만 사용. 초기 RIS 맥락 확인으로 같은 프로젝트의 `.ris/project.yaml`, `research/INDEX.md`, `research/CONTEXT.md`, `research/plans/choice.md`, `HANDOFF.md`, `observations/label.txt`, `observations/sim.txt`도 읽었으나 답에 그 내용은 사용하지 않았습니다. 동작 — 읽기만, 사실 저장이나 프로젝트 파일 수정 없음. 역할 — `release/agents/researcher.toml`의 RIS Researcher 및 `release/skills/ris/SKILL.md`의 좁은 사실 조회 기준.
