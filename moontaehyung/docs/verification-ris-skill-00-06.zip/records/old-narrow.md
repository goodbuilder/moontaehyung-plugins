표 2, 행 c의 지연시간은 p95 기준 15밀리초(ms)이며, 관측 대상은 Larch-1 시뮬레이터(batch 4)입니다.

근거: `/tmp/ris-skill-work-20261123-d6wegE/inputs/table.md`의 “Table 2, row c” 항목을 직접 확인했습니다. 표 3은 요청 범위가 아니므로 사용하지 않았습니다.

작업 기록: 사용 파일 `inputs/table.md`; 실행/행동 `cat /tmp/ris-skill-work-20261123-d6wegE/inputs/table.md`로 내용 확인; 적용 역할 정의 `old/agents/researcher.toml`의 “Investigates technical questions, approach families, evidence, contrary findings, and research coverage for RIS projects.” `$ris`의 narrow-answer 예외에 따라 요청된 단일 파일에서 사실을 추출했습니다.
