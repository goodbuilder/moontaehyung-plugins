모드: RIS의 좁은 사실 조회(Narrow answer).

Rowan 장비 / workload K / required revision 9에 대해 확인 가능한 자료는 `inputs/measure-partial.txt`입니다. 기록된 값은 p50=12.4 ms이고, p95는 **수집되지 않았습니다**(ACQ-794, block 5, row 19; receipt token `bo72`). 따라서 p95가 20 ms 이하인지 판정할 수 없습니다. p95 미수집은 기준 초과를 뜻하지 않으며, 기준 충족도 입증하지 않습니다. 장비에 직접 접근하거나 추가 측정을 하지는 않았습니다.

작업 기록: 제공된 가이드와 요청 파일을 읽고, RIS skill의 요청 분류 및 단일 사실 응답 지침을 적용했습니다. 요청에서 허용한 측정 파일 하나만 읽었습니다. 그 값으로 답변을 작성하고 이 기록을 저장했습니다. 연구 프로젝트 내부에는 기록을 쓰지 않았습니다.

최종 작업 명세 — 파일: `/tmp/ris-skill-work-20261123-d6wegE/guide.txt`, `/tmp/ris-skill-work-20261123-d6wegE/inputs/request-solo-partial.txt`, `/tmp/ris-skill-work-20261123-d6wegE/final/skills/ris/SKILL.md`, `/tmp/ris-skill-work-20261123-d6wegE/inputs/measure-partial.txt`, `/tmp/ris-skill-work-20261123-d6wegE/records/new-partial.md`; 명령/작업: `cat`으로 지정 자료 읽기, `mkdir -p`로 기록 디렉터리 생성, 이 Markdown 기록 작성; 실제 적용 역할 정의: RIS `SKILL.md`의 **Narrow answer** 모드(별도 Researcher 역할 지시 파일은 할당되지 않아 읽거나 적용하지 않음).
