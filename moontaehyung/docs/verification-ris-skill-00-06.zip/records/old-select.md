# RIS Researcher 지시 범위 검토

## 적용 경로

- 선택 경로: 카탈로그의 `ris` 경로 (`/tmp/ris-skill-work-20261123-d6wegE/old/skills/ris/SKILL.md`).
- 세부 분류: RIS Skill의 **Narrow answer or meta question**. 사용자는 프로젝트 조사를 시작하거나 이어 달라고 한 것이 아니라, 플러그인의 Researcher 역할 지시가 좁은 자료 확인을 과도한 조사로 확장시키는지 물었다. 따라서 직접 지시를 비교해 답했고, 전체 조사 인벤토리나 웹 검색은 수행하지 않았다.
- 앱 파서 경로는 특정 앱 질문이 아니어서 선택하지 않았다.

## 답변

네. Researcher 역할 템플릿에는 좁은 질문에도 조사를 넓힐 수 있는 지시가 있습니다. 특히 [researcher.toml](/tmp/ris-skill-work-20261123-d6wegE/old/agents/researcher.toml:20)의 “Required procedure (complete every step)”가 모든 배정에 7단계를 의무화합니다. 그 아래에는 최소 세 가지 유형의 검색(23–27행), 전체 후보 목록과 누락 점검(28–29행), 자원-미지수 행렬 및 목표를 만족한 뒤에도 서로 다른 원리의 후보 세 개 추가(32–35행), 각 단서의 추가 조사와 미탐색 프런티어 상위 세 항목 조사(36–42행), 그리고 모든 단계를 마치기 전에는 반환하지 말라는 요구가 있습니다. 따라서 한 줄의 출처 확인도 Researcher에게 배정되면 넓은 조사로 번질 수 있습니다.

다만 상위 [RIS Skill](/tmp/ris-skill-work-20261123-d6wegE/old/skills/ris/SKILL.md:30)은 사실 조회나 RIS 개선에 관한 메타 질문을 **Narrow answer or meta question**으로 분류해 직접 답하고 전체 인벤토리는 돌리지 말라고 합니다. 폭넓은 접근 계열 탐색은 답에 접근 계열·근거·계획이 필요한 **Explore** 모드에 놓여 있습니다(28–31행 및 65–67행). [role-workflow.md](/tmp/ris-skill-work-20261123-d6wegE/old/skills/ris/references/role-workflow.md:14)도 Researcher를 “범위가 정해진 조사”가 필요한 결론에 호출하도록 설명합니다. 즉 상위 Skill에는 범위 축소 규칙이 있지만 Researcher 템플릿의 무조건적 7단계 절차가 이를 덮어쓸 여지가 있는 지시 불일치입니다. 모든 한 줄 확인이 반드시 넓은 조사로 가야 한다고 상위 Skill이 요구하는 것은 아닙니다.

수정 방향은 Researcher의 7단계를 모든 업무의 기본값으로 두지 않고, 접근 계열 비교가 필요한 Explore 과제나 Coordinator가 명시적으로 지정한 조사에만 적용하는 것입니다. 좁은 출처 확인은 요청된 출처와 위치를 확인하고 검토 범위·불확실성을 보고하게 하며, 확인 중 결정에 영향을 주는 의존성이나 추가 질문이 발견될 때만 그 범위를 넓히면 됩니다. 이번 검토에서는 지시를 수정하지 않았습니다.

## 실제로 열어 본 파일

1. `/tmp/ris-skill-work-20261123-d6wegE/inputs/catalog-larch.txt`
2. `/tmp/ris-skill-work-20261123-d6wegE/inputs/request-router4.txt`
3. `/tmp/ris-skill-work-20261123-d6wegE/old/skills/ris/SKILL.md`
4. `/tmp/ris-skill-work-20261123-d6wegE/old/skills/ris/references/role-workflow.md`
5. `/tmp/ris-skill-work-20261123-d6wegE/old/skills/ris/references/agent-installation.md`
6. `/tmp/ris-skill-work-20261123-d6wegE/old/agents/researcher.toml`

## 범위 및 검증 상태

- `CONFIRMED`: 위 파일의 지시 문구 사이에 적용 범위 차이가 있다.
- `NOT_RUN`: 실제 플러그인 런타임에서 Researcher가 한 줄 확인을 받았을 때의 동작은 실행하지 않았다.
- `NOT_CHANGED`: 플러그인 지시 파일은 수정하지 않았다.
