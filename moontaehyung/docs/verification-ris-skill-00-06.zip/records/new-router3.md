RIS가 제품/저장소와 RIS Skill·플러그인·역할 지침 중 어느 쪽을 가리키는지 확인이 필요합니다. 어느 대상을 고치면 될까요?

기록 메타: 읽은 파일=guide.txt, inputs/request-router3.txt, phase12/skills/ris/SKILL.md; 실행/조치=RIS 요청 분류 규칙 확인, 기존 출력 레코드 부재 확인, 이 답변 기록; 코드 변경·테스트=없음; 사용한 역할 정의=phase12/skills/ris/SKILL.md의 요청 분류 규칙(별도 커스텀 역할 정의는 사용하지 않음).
