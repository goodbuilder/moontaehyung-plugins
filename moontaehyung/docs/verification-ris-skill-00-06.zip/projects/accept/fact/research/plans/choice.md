---
ris_id: "cdfa0cc7-d09a-4a18-bdcb-1d11eec20a81"
project_id: "5656dc25-fa82-40a2-9168-993f2910070f"
kind: "plan"
status: "draft"
created: "2026-11-23T11:07:13.123575+00:00"
---

# 장비 후보

## D-51 장비 선택

목표 장비·부하 L·동일 revision. p95 ≤20ms, 나머지 필수 조건 충족. 아직 사용자가 방법을 선택하지 않았다.

## D-52 라벨 판독

독립 인쇄 표본 2의 라벨은 판독됨 (label.txt §1). 지연시간 측정에 의존하지 않는다.
