# 현재 인계

- **현재 단계:** D-51의 새 실측을 반영했다. 현재 A가 기준 충족 후보로 확인되어 권고되며, 최종 선택은 사용자에게 남아 있다.
- **정본 계획:** [장비 후보 계획](research/plans/choice.md) — 활성 결정 D-51. 현재 상태와 미해결 사항은 [현재 연구 맥락](research/CONTEXT.md)에 있다.
- **A의 새 근거:** [observations/board-a.txt](observations/board-a.txt) ACQ-078 행 3은 A·목표 장비·부하 L·동일 revision의 장비 p95 실측 17ms를 기록한다. [observations/protocol.txt](observations/protocol.txt) §2에 따라 유효한 목표 조건 실측이고 다른 필수 조건도 충족하므로 p95 상한 20ms보다 3ms 낮다.
- **B의 근거:** [observations/board.txt](observations/board.txt) ACQ-041 r2 행 8은 B p95 24ms로 r1의 18ms를 같은 원측정의 전사 정정으로 대체한다. B는 상한을 4ms 초과한다. r1·r2는 별도 측정이 아니다.
- **현재 결론:** 현재 기록된 A/B 비교에서는 A를 D-51 권고 후보로 제시한다. SIM-2의 A 15ms는 시뮬레이션이며 장비 측정값으로 사용하지 않는다. A 권고는 사용자 최종 선택이나 실제 장비 선택이 아니다.
- **다음 조치:** 사용자의 최종 선택을 기다린다. 새 후보·조건 변경·정정 측정이 들어오면 동일 조건 여부를 확인하고 계획을 갱신한다. 이번 갱신에서 새 시험은 하지 않았다.
- **별도 항목:** D-52 라벨 판독 성공은 장비 지연시간 결론과 무관하다.
