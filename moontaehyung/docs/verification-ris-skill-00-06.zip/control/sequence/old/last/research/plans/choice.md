---
ris_id: "cdfa0cc7-d09a-4a18-bdcb-1d11eec20a81"
project_id: "5656dc25-fa82-40a2-9168-993f2910070f"
kind: "plan"
status: "draft"
created: "2026-11-23T11:07:13.123575+00:00"
---

# 장비 후보

## D-51 장비 선택

목표 장비·부하 L·동일 revision. p95 ≤20ms, 나머지 필수 조건 충족. 최종 선택은 사용자에게 남아 있다.

### 현재 권고 (2026-11-23; 사용자 최종 선택 대기)

- **A를 현재 권고한다.** [observations/board-a.txt](../../observations/board-a.txt) ACQ-078 행 3은 후보 A의 목표 장비·부하 L·동일 revision 실측 p95를 17ms로 기록한다. [observations/protocol.txt](../../observations/protocol.txt) §2에 따라 유효한 목표 조건 실측이고 다른 필수 조건도 충족한다. p95 상한 20ms보다 3ms 낮다. 이 근거로 A는 현재 기록된 D-51 조건을 충족한다고 입증된다.
- **B는 현재 기준을 충족하지 않는다.** [observations/board.txt](../../observations/board.txt) ACQ-041 r2 행 8은 목표 장비 B·동일 부하 L·p95 24ms로 정정한다. 유효한 목표 조건 실측이며 다른 필수 조건은 충족하지만, 상한 20ms를 4ms 초과한다.
- **B의 r1 값은 대체되었다.** r2는 같은 원측정의 전사 오류를 바로잡아 r1의 18ms를 대체한다. r1·r2는 별도 측정이나 장비 revision이 아니라 문서 정정 순번이므로 둘을 평균하거나 r1을 선택하지 않는다.
- **A의 SIM-2 15ms는 적격 판정 근거로 사용하지 않는다.** [observations/sim.txt](../../observations/sim.txt)의 값은 시뮬레이션이고 장비 실측을 대신할 수 없다. A에 대해서는 새 유효 실측인 ACQ-078의 17ms를 기준으로 판단한다.
- **현재 결론:** 현재 기록된 A/B 비교에서는 A가 D-51 조건을 충족하는 후보로 확인되어 권고된다. 이는 권고이며 사용자 최종 선택이나 실제 장비 선택이 완료된 것은 아니다.

### 이전 판단 이력

초기 검토는 ACQ-041 r1의 18ms를 근거로 B를 조건부 우선 권고했고, protocol §2 확인 후 B를 확정 권고했다. board.txt r2가 같은 원측정의 전사 오류를 정정해 24ms로 대체하면서 그 B 권고는 superseded되었다. A 장비 실측이 없던 시점에는 적격 후보 미입증(INSUFFICIENT_EVIDENCE)이 현재 판단이었다. 새 ACQ-078의 유효 A 실측 17ms가 그 상태를 supersede한다. 이전 노트와 판단의 preimage는 .ris/history에 보존한다.

### 다음 조치

사용자의 D-51 최종 선택을 기다린다. 현재 증거상 A를 권고한다. 새 후보나 조건 변경 자료가 제시되면 목표 장비·부하·revision·p95 산출법이 같은지 확인한 뒤 비교를 갱신한다. 이 갱신에서 새 시험이나 장비 실행은 하지 않았다.

## D-52 라벨 판독

독립 인쇄 표본 2의 라벨은 판독됨 (label.txt §1). 지연시간 측정에 의존하지 않는다.
