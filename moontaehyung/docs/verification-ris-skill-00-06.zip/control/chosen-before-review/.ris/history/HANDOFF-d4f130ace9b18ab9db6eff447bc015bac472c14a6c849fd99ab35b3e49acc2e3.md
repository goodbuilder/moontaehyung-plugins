# 현재 인계

[장비 후보 D-51](research/plans/choice.md) 연구를 재개한다.
