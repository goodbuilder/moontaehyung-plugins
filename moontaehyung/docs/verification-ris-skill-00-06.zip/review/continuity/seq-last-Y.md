# D-51 후속 근거 갱신

## 사용자에게 보낼 답변

새 원자료 `observations/board-a.txt`의 ACQ-078 행 3은 후보 A가 목표 장비·부하 L·동일 revision에서 측정한 p95 17ms라고 기록합니다. `observations/protocol.txt` §2는 해당 조건의 장비 로그가 유효하고 나머지 필수 조건도 충족한다고 확인합니다. 따라서 A는 D-51의 p95 ≤20ms 기준을 3ms 여유로 충족하며, 현재 권고를 A로 갱신했습니다.

B는 ACQ-041 r2의 정정 p95 24ms가 r1의 18ms를 대체하므로 기준을 4ms 초과합니다. 이전 B 권고와 근거는 기존 history에 보존했습니다. A의 시뮬레이션 p95 15ms는 실측 근거로 사용하지 않았습니다. D-52 라벨 결과는 별도 항목으로 두고 변경하지 않았습니다.

A는 권고일 뿐 사용자의 최종 선택은 아직 기록되지 않았습니다. 다음 단계는 사용자의 선택이며, 이번 요청에서는 시험을 수행하지 않았습니다.

## 갱신 및 확인

- 갱신: `projects/snapshot/seq/research/plans/choice.md`의 D-51 권고·근거와 변경 이력, `research/CONTEXT.md`, 프로젝트 `HANDOFF.md`. D-51 판단을 “적격 후보 미확인”에서 “A 권고”로 바꾸고 B의 불합격 판단은 유지했습니다.
- 보존: 이전 B 권고 원문은 `projects/snapshot/seq/.ris/history/5e0902134b3007cff112c145fce40942c9b62f3bdaab5497e7d5b7c3b404cfb5.md`에 남아 있습니다. RIS helper가 갱신 전 계획·맥락의 preimage도 `.ris/history`에 보관했습니다. 핸드오프 직접 수정 전 preimage도 `.ris/history/HANDOFF-<sha256>.md`에 보존했습니다.
- 범위: `board-a.txt` 등 관측 원본, 사용자 선택, D-52 계획 절을 수정하지 않았습니다. 계획의 D-52 절이 preimage와 동일함을 확인했습니다.
- 검증: `ris.py --project projects/snapshot/seq check` 결과 `ok: true`, 오류 0, 경고 0. 계획·CONTEXT·HANDOFF의 A 17ms 근거와 미확정 사용자 선택이 일치하고 과거 B 권고 파일이 존재함을 확인했습니다.
- 한계: 제공된 스냅샷에 Project Plan graph 검사기와 Archify renderer가 없어 그래프/HTML 검증 또는 재생성은 수행하지 않았습니다. 이 프로젝트에서 HTML 파일은 확인되지 않았습니다. 실제 장비 시험과 외부 조회도 하지 않았습니다.

## 조치 영수증

- 읽은 입력·프로젝트 파일: `inputs/request-seq-last.txt`; `projects/snapshot/seq/HANDOFF.md`; `.ris/project.yaml`; `research/INDEX.md`, `research/CONTEXT.md`, `research/plans/choice.md`; `observations/protocol.txt`, `board.txt`, `board-a.txt`, `sim.txt`; 과거 B 권고 history; RIS·Project Plan 스냅샷의 해당 Skill 및 참조. Researcher 역할 정의는 경계 확인을 위해 읽었습니다.
- 쓴 파일: 위의 계획·CONTEXT·HANDOFF 및 이 기록 `records/run-seq-last.md`; managed-note preimage 및 HANDOFF preimage는 `.ris/history`에 보존.
- 실행/행동: RIS helper의 preimage hash 검증 업데이트 2회, HANDOFF 사전 hash·재확인·preimage 백업을 포함한 guarded update, RIS `check`, D-52 preimage 대조 및 note 간 일치 확인.
- 실제 적용 역할 정의: Coordinator가 위임한 RIS 결정 갱신 작업으로, `deliver/skills/ris/SKILL.md`의 correction 절차와 `deliver/skills/project-plan/SKILL.md`의 canonical-plan/history 규칙을 적용했습니다. `agents/researcher.toml`은 읽어 역할 경계를 확인했으나, 별도 Researcher 배정이 아니므로 그 역할을 canonical decision owner로 사용하지 않았습니다.
