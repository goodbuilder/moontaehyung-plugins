# D-51 요청 처리 독립 감사

**Overall status: BLOCKED** — 세 요청의 범위 처리는 제공된 기록과 일치하지만, D-51의 핵심 동일-revision 조건은 허용된 증거로 판정할 수 없다. 따라서 B의 수치는 목표 revision에 대한 적격 결과로 확인되지 않았다. 이 상태는 요청 처리의 실패를 뜻하지 않는다. 추천과 사용자 선택 기록은 그 한계를 명시했다.

## 범위와 확인 결과

- **nodoc — 추천만, 무기록:** `records/release-choice.md:7-11`은 조건부 B 추천, A 보류 사유, 재검토 조건, 독립 검토 미수행, 읽기만 했다는 실행 주장을 기록한다. 현재 `projects/snapshot/nodoc/research/plans/choice.md:11-17`은 여전히 사용자가 선택하지 않았다고 하며, `research/CONTEXT.md:11-27`에도 판단 기록이 없다. 현재 자료에서 잔존하는 추천 기록이나 선택 변경은 보이지 않는다. 다만 원시 실행 로그나 전후 해시는 제공된 범위에 없어 무쓰기 주장을 독립적으로 바이트 단위 입증하지는 못했다.
- **chosen — 사용자 선택 기록:** 요청은 B 선택과 그 이유를 기록하도록 했고, `records/release-choice.md:15-17`은 plan, context, handoff 갱신을 주장한다. 실제 현재 기록은 B와 사용자 이유를 명시하고 선택을 전체 검증으로 취급하지 않는다 (`projects/snapshot/chosen/research/plans/choice.md:15-24`, `research/CONTEXT.md:17-29`, `HANDOFF.md:3-10`). 이는 사용자 선택을 기록한 것이며 자동 변경을 주장하지 않는다.
- **별도 완료 결과 유지:** D-52 라벨 판독 결과는 chosen의 D-51 선택과 분리되어 plan에 남아 있고, 원 관측도 있다 (`projects/snapshot/chosen/research/plans/choice.md:26-28`, `observations/label.txt:1`). nodoc에도 라벨 결과가 별도 항목으로 남아 있다 (`projects/snapshot/nodoc/research/plans/choice.md:15-17`). 라벨 결과를 D-51 지연 조건의 근거로 사용한 흔적은 없다.
- **fact — 숫자만, 무저장:** 답은 `18ms (p95)`와 출처 `observations/board.txt`, ACQ-041 r1 행 8만 포함한다 (`records/release-choice.md:19-23`). 이는 board의 유일한 보고값과 일치한다 (`projects/snapshot/fact/observations/board.txt:1`). fact의 현재 계획·맥락에는 D-51 판단이 추가되지 않았다 (`research/plans/choice.md:11-17`, `research/CONTEXT.md:11-27`). 문맥 확인용 다른 파일을 읽었다는 실행 설명은 있지만, 추가 산출물이나 저장을 주장하지 않는다.
- **독립 연구 검토:** 요청은 별도 감사자가 배정되지 않았다고 명시한다. nodoc 추천 및 chosen 선택 기록은 독립 검토가 수행되지 않았다고 정확히 표시한다 (`records/release-choice.md:9,15`, `projects/snapshot/chosen/research/plans/choice.md:21`, `HANDOFF.md:6-7`). 이 문서는 요청 처리에 대한 독립 감사이며, D-51의 독립 연구 검토를 소급해 수행한 것으로 보지 않는다.
- **범위 밖 산출물:** 확인하지 못했다. nodoc은 추천만 제시했고, chosen은 요청한 기존 기록에 선택과 이유를 기록했으며, fact는 요청한 한 숫자와 출처만 답했다. 네트워크 검색·위임·외부 실행·독립 연구 검토 완료를 주장하지 않는다 (`records/release-choice.md:3,11,15-23`).

## A-001 — 목표 revision에 대한 측정 귀속 누락

```yaml
id: A-001
severity: high
scope: evidence
reference: projects/snapshot/chosen/research/plans/choice.md#D-51
evidence: "D-51은 목표 장비·부하 L·동일 revision 및 p95 ≤20ms를 요구한다 (lines 11-13). board.txt:1은 B, 부하 L, p95 18ms를 보고하지만 revision은 적지 않는다. 선택 기록 lines 18-19와 release-choice.md:9,15도 목표 revision 일치를 확인하지 못했다고 명시한다."
impact: "18ms가 기준 이하라는 산술은 맞지만, 해당 측정이 목표 revision에 적용되는지는 확인되지 않는다. 그러므로 B의 목표 revision 적격성이나 전체 필수 조건 충족은 확정할 수 없다. nodoc의 조건부 추천은 이 제한을 공개했으며, chosen 기록도 전체 인수 판정으로 확대하지 않았다."
required_correction: "ACQ-041 r1 행 8의 실제 장비 revision을 기존 원자료에서 확인해 D-51 목표 revision과 대조한다. 귀속 자료가 없다면 revision 일치를 미확인 상태로 유지하고 B를 검증 완료로 표시하지 않는다."
owner: researcher
re_audit: "ACQ-041 r1 행 8과 목표 revision의 일치 여부, p95 적용성 및 그에 의존하는 D-51 추천 근거만 재검토한다."
residual_uncertainty: "허용된 board 관측에는 revision 정보가 없다. 원자료에서 귀속 정보를 찾을 수 있는지는 확인되지 않았다."
```

## 증거 한계

요청문, 지정된 감사 지침과 계약, 세 프로젝트의 HANDOFF/INDEX/CONTEXT/plan/observation 현재 파일, `records/release-choice.md`만 확인했다. `nodoc`과 `fact`의 응답이 현재 파일에 반영되지 않은 것은 확인되지만, 제한된 자료만으로는 과거의 쓰기 후 복원 여부를 증명할 수 없다. 실행 원시 로그·전후 해시, 프로젝트 내부 이력, revision 원자료, 나머지 필수 조건의 항목별 증거는 조사하지 않았다. 전체 연구 커버리지·계획 타당성이나 D-51의 과학적 독립 검토는 이번 범위에서 수행하지 않았다.
