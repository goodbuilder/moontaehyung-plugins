# D-51 재평가와 인계

## 모드
기존 추천을 새 프로토콜 확인에 따라 재평가하고 현재 기록과 인계를 갱신했다.

## 현재 권고
현재 제공된 조건 일치 장비 실측을 기준으로 후보 B를 권고한다. `observations/board.txt`의 ACQ-041 r1 행 8은 목표 장비 B와 부하 L에서 p95 18ms를 기록한다. `observations/protocol.txt` §2의 시험 의뢰자 확인은 제공된 장비 관측이 목표 장비·부하 L·지정 revision·정해진 p95 산출법에 따른 유효한 실측이며 나머지 필수 조건도 충족한다고 명시한다. 따라서 B는 p95 ≤20ms를 2ms 여유로 충족한다. 프로토콜은 r1/r2가 장비 revision이 아니라 로그 문서 정정 순번이라고 확인한다.

후보 A의 p95 15ms는 `observations/sim.txt`의 시뮬레이션 값으로, 장비 실측을 대신하지 못하며 실제 D-51 기준 충족을 보여주지 않는다. 현재 프로젝트에 있는 자료에서 조건에 맞는 장비 실측이 확인되는 후보는 B다. 이 권고는 사용자의 방법 선택이 아니다. 이후 정정 로그가 제공되면 D-51 판단을 다시 확인한다.

## 기록 및 검증
기존 `research/plans/choice.md`, `research/CONTEXT.md`, `HANDOFF.md`를 갱신했다. D-52 내용과 기존 RIS ID를 유지했고, 앞선 조건부 권고를 `.ris/history/` preimage로 보존했다. 새로운 프로젝트 artifact나 시각화는 만들지 않았다.

최종 스냅샷의 `ris.py check`는 `ok: true`, errors 0, warnings 0을 반환했다. 외부 검색과 ACQ-041 원문은 열지 않았다. 이 구조 검사는 연구 주장의 독립 검수가 아니다.

## 다음 인계
사용자 선택은 미기록 상태로 남긴다. 사용자가 A와 직접 비교하려면 같은 조건의 장비 실측이 필요하다. 현재 project listing에 제공된 보드 관측은 r1이며, 새 정정본이 나오면 기존 추천에 미치는 영향을 검토한다. D-52는 별도 항목으로 유지한다.

작업·역할 기록: 읽음 — `inputs/request-seq-qualified.txt`, `projects/snapshot/seq/.ris/project.yaml`, `research/INDEX.md`, `research/CONTEXT.md`, `research/plans/choice.md`, `HANDOFF.md`, `observations/protocol.txt`, `observations/board.txt`, `observations/sim.txt` (앞선 검토에서 `observations/label.txt`도 확인), final snapshot의 RIS Skill·`research-exploration.md` 정정/추천 섹션·`operations.md`·`shared-outputs.md` 인계 섹션·`agents/researcher.toml`; 갱신 — `research/plans/choice.md`, `research/CONTEXT.md`, `HANDOFF.md`, helper/direct hash-guarded preimage backups; 실행 — final snapshot `ris.py update`, preimage-guarded HANDOFF refresh, `ris.py check` (PASS, structure only), delegation 없음; 실제 역할 정의 — final `agents/researcher.toml`의 RIS Researcher, bounded evidence correction/recommendation 범위 (파일 표기 모델은 gpt-6.1-sol/medium이며 별도 agent는 spawn하지 않음).
