## 기존 자료에 따른 재검토

`inputs/pooled.txt`의 내용만 기준으로 보면, **Paper L과 M에 근거한 결론은 재검토해야 하고, Paper N의 지역 모집단 결과는 유지할 수 있습니다.**

### 재검토할 결론: Paper L·M

- Paper L §3의 `+8`과 Paper M §2의 `+7`은 서로 다른 독립 재현 결과가 아닙니다. 두 논문은 같은 등록부 X를 쓰고, 그룹 2를 대조군으로 분류한 동일한 구성을 사용했습니다.
- 등록부 관리자의 정정에 따르면 그룹 2에는 두 처치가 섞여 있었습니다. 따라서 그룹 2를 대조군으로 둔 전제가 두 분석 모두에서 깨집니다. 이 분석을 유효한 처치 효과의 근거로 삼은 결론과, L·M을 독립적인 두 연구처럼 세어 뒷받침한 종합 결론을 다시 검토해야 합니다.
- 보정된 결과가 없으므로 `+8` 또는 `+7`을 대체할 효과를 계산할 수 없습니다. 이 정정만으로 효과가 0이거나 반대 방향이라고 결론 내릴 수도 없습니다. 기존 수치는 해당 분류를 사용한 분석의 보고값으로 남지만, 분류 오류가 바로잡힌 효과 추정치로 해석해서는 안 됩니다.

### 유지할 수 있는 결론: Paper N의 지역 결과

Paper N §5는 다른 학교의 독립적인 등록부 Y를 사용해 자기 지역 모집단에서 `+3`을 보고했고, X나 X의 분류를 사용하지 않았습니다. 그러므로 X의 정정은 N의 보고 결과를 바꾸지 않습니다. `+3`은 **N이 조사한 지역 모집단에 대한 결과**로 유지할 수 있습니다. 이 결과만으로 L·M의 분석을 복구하거나 더 넓은 모집단에 같은 효과가 있다고 일반화할 수는 없습니다.

### 종합

기존 종합 결론이 L·M의 `+8`, `+7`을 별개의 독립 근거로 집계했다면 그 근거의 수와 무게를 수정해야 합니다. 현재 유지 가능한 것은 N의 독립적인 지역 결과이며, L·M에 의존한 효과 결론은 X의 그룹 2를 올바르게 분류한 결과가 확보될 때까지 미확정입니다. 제공된 자료에는 그 보정 결과가 없습니다.

---
실행 기록 — 파일: `guide.txt`, `inputs/request-transfer.txt`, `inputs/pooled.txt`, `snapshot/.claude-plugin/plugin.json`, `snapshot/.codex-plugin/plugin.json`, `snapshot/templates/ris-coordinator-AGENTS.md`, `snapshot/agents/*.toml`, `snapshot/skills/ris/SKILL.md`, `snapshot/skills/ris/references/research-exploration.md`, `snapshot/skills/ris/references/role-workflow.md`; 작업: 읽기 전용으로 입력과 지정된 이전 플러그인 지침을 확인하고 위 답변을 기록함; 적용한 실제 역할 정의: `snapshot/agents/researcher.toml`의 RIS Researcher.
