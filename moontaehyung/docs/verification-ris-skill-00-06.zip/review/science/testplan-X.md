# T4 · T5 판정

## T4 — 두 모델 주장과 판단을 바꿀 확인

**현재 지지할 수 있는 결론:** A와 B 중 어느 쪽이 일반적으로 더 빠르다고는 아직 지지할 수 없습니다. 주어진 합성 timing trial에서는 같은 기계·입력 설정의 batch 32에서 둘 다 110 ms였습니다. 그 한 점은 해당 조건에서 동률이라는 관측을 지지하지만, 다른 batch 크기에서의 우열은 보여 주지 않습니다.

A가 고정 setup 시간을 줄이고 B가 항목당 시간을 줄인다는 설명을 단순 가산 모델에 적용하면, 두 개선이 batch 32에서 같아지는 경우 32보다 작은 batch에서는 A, 큰 batch에서는 B가 유리할 수 있습니다. 이는 제공된 설명에서 나온 **모델 추론**이지, 다른 크기에서 확인된 결과가 아닙니다. 실제 batch 분포와 비선형 효과도 아직 모릅니다.

**판단을 가를 최소 확인:** Engineer의 역할 정의대로 측정 구성과 판정 기준을 먼저 고정합니다. 같은 기계, 입력, 소프트웨어 설정에서 A와 B를 작은 크기·32·큰 크기(예: 8·32·128)에 모두 적용하고, 각 조건의 전체 경과시간을 반복 측정합니다. 실행 순서를 번갈아 배치해 순서·부하 변화가 한 대안에만 치우치지 않게 하고, setup과 항목별 시간을 따로 기록할 수 있으면 두 설명도 직접 확인합니다. 실제 현장 batch 분포가 주어지면 그 분포에서의 총 시간을 비교합니다. 이 숫자들은 제안한 시험 수준이며, 관측 결과가 아닙니다.

- 반복 측정에서 A가 목표 batch 분포의 총 시간을 낮추면 A를 지지합니다.
- B가 낮추면 B를 지지합니다.
- 크기에 따라 우열이 바뀌면 현장 batch 분포가 결정을 가릅니다.
- 차이가 재현되지 않거나 측정 조건이 흔들리면 판정은 보류합니다. 그 결과를 우열로 바꾸지 않습니다.

RIS role-workflow의 경계에 따라 Engineer는 **무엇을 측정하고 어떤 관측이 기준을 충족하는지** 정의하며, Planner는 이 확인을 선택 전에 놓고 각 결과(보류 포함)가 어느 선택을 지원하는지 연결합니다. 이에 따라 위 측정은 다음 선택보다 앞서야 합니다. 현재 자료에는 목표 batch 분포나 시간 차이의 수용 기준이 없으므로, 그런 기준을 임의로 만들어 결론에 넣지 않았습니다.

**근거:** `inputs/two-models.txt`. 그 밖의 batch 크기 측정은 제공되지 않았습니다.

기록: 읽은 파일 — `inputs/request-decision.txt`, `inputs/two-models.txt`, `snapshot/skills/ris/SKILL.md`, `snapshot/skills/ris/references/role-workflow.md`, `snapshot/agents/claude/engineer.md`, `snapshot/agents/claude/planner.md`, `snapshot/agents/engineer.toml`, `snapshot/agents/planner.toml`; 수행 — 지정 파일을 읽고 역할 경계에 따라 직접 분석해 이 기록에 작성; 적용한 실제 역할 정의 — snapshot의 RIS Coordinator/좁은 답변 절차, Engineer, Planner. Engineer와 Planner는 역할 정의를 적용한 분석이며 별도 agent 실행은 하지 않았습니다.

