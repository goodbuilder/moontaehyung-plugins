## (1) P, Q, R, S 묶음

**판정:** 이 묶음에는 서로 다른 조건에서 나온 성능 보고가 두 개 있습니다. P는 합성 작업 부하 L의 시뮬레이션 시험 M에서 p95 지연시간 15 ms를 보고합니다(P §2). Q는 P의 15 ms를 재현했다고 표현하지만 관측을 수집하지 않았다고 명시하므로 독립 측정이 아닙니다(Q ¶4). R도 P §2의 M 시리즈를 복사했고 새 측정이 없다고 밝힙니다(R note 7). 따라서 Q와 R은 15 ms 결과의 독립 재현 근거를 추가하지 않습니다.

S는 M과 독립적으로 새 작업 부하 N을 물리 보드 Elm에서 수집했고 p95 18 ms였다고 보고합니다(S §4). 제공된 문구를 기준으로 하면, **N/Elm 조건에서 p95 18 ms라는 별도의 측정 보고가 하나** 있습니다. 다만 이것은 시뮬레이션의 M/L 조건과 다르므로 P의 15 ms를 같은 조건에서 독립 재현한 결과라고 할 수 없습니다. S의 문구는 독립 수집을 주장하지만, 여기 제공된 발췌문에는 원시 측정값이나 수집 절차가 없어 그 독립성을 별도로 감사할 수는 없습니다.

요약하면, M/L의 15 ms는 P의 단일 시뮬레이션 보고뿐입니다. 별도 조건의 하드웨어 측정 보고는 S의 18 ms 하나입니다. 두 값을 합쳐 하나의 재현 성능치로 만들거나, 하드웨어 결과를 시뮬레이션 결과에 일반화할 근거는 없습니다.

## (2) P, Q, R, S-undisclosed.txt 묶음

**판정:** 이 묶음만으로는 15 ms 결과의 독립 재현을 주장할 수 없습니다. P는 시뮬레이션 시험 M, 합성 작업 부하 L에서 p95 15 ms를 보고합니다(P §2). Q는 관측 없이 P의 값을 재현했다고 서술하고(Q ¶4), R은 P의 M 시리즈를 복사했다고 밝히므로(R note 7), 둘 다 독립 측정을 보태지 않습니다.

S-undisclosed는 p95 18 ms를 보고하지만, 표본의 정체, 앞선 보고와의 관계, 수집 환경을 문서화하지 않습니다(S §4). 따라서 이 18 ms가 독립 수집인지, P와 같은 자료 계보인지, 어떤 조건의 성능인지 판별할 수 없습니다. 이 묶음에서 확인 가능한 것은 P의 단일 시뮬레이션 보고와 출처 관계가 불명인 18 ms 보고뿐입니다. 18 ms를 독립 성능 측정이나 P의 재현으로 세지 않습니다.

## 공통 한계

제공된 발췌문에는 원시 시계열, 표본 수, 반복 횟수, 측정 프로토콜 또는 불확실도 정보가 없습니다. 따라서 p95 추정의 정밀도·변동성, 통계적 재현성, 다른 작업 부하나 장비로의 일반화는 판단할 수 없습니다. 여기서의 판정은 발췌문이 명시한 계보와 조건에 한정됩니다.

작업 추적 — 읽은 파일: `guide.txt`, `inputs/request-lineage.txt`, `inputs/P.txt`, `inputs/Q.txt`, `inputs/R.txt`, `inputs/S.txt`, `inputs/S-undisclosed.txt`, `snapshot/skills/ris/SKILL.md`, `snapshot/skills/ris/references/research-exploration.md`(§§ Completion and recommendation checks, Evidence behind a recommendation), `snapshot/agents/researcher.toml`; 실행/행동: `cat`으로 지정 안내·입력·역할 파일 열람, `rg -n`으로 관련 단락 위치 확인, `sed -n '144,195p'`로 해당 기준 확인, 지정 기록 파일 작성; 사용한 역할 정의: `snapshot/agents/researcher.toml`의 RIS Researcher—bounded evidence check. 위임·외부 검색·프로젝트 내 변경은 수행하지 않음.
