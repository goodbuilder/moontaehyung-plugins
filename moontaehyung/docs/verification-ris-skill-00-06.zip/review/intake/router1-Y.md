제공된 `old` 스냅샷 기준으로, RIS 공통 위임 지침은 `snapshot/skills/ris/SKILL.md`에 있고, Researcher 역할의 구체적인 절차는 `snapshot/agents/researcher.toml`에 있습니다. 따라서 역할 정의의 원본은 스냅샷의 `agents/researcher.toml`이며, 프로젝트 `.codex/agents/`나 개인 `~/.codex/agents/`에 설치되는 파일은 그 템플릿의 사본입니다. 수정은 설치 캐시가 아닌 플러그인 소스에서 하도록 안내되어 있습니다. 이 스냅샷만으로 현재 런타임에 해당 에이전트가 등록되어 있는지는 확인되지 않습니다.

조사를 맡길 때는 Coordinator가 질문·의존성·통합·전체 완료를 책임지고, 입력이 준비된 독립 과제는 가능한 전문 에이전트에 맡깁니다. Researcher에게는 결과와 구체적 질문, 제약, 관련 안정 ID, 출처와 입력 revision, 산출 형식/경로, 인수 기준, 허용된 행동을 전달합니다. Researcher는 배정된 질문의 출처 기반 조사와 조사 범위 판단을 맡고, 원본 위치와 실제 확인 범위, 반대 증거, 결론이 달라지는 조건, 남은 공백을 반환합니다. canonical 결정 그래프와 전체 실행 완료는 Researcher 소유가 아닙니다.

Researcher 절차는 요청·RIS 탐색 규칙을 읽고, 이름이 나온 제품·표준·도구·데이터셋을 빠짐없이 조사하며, 서로 다른 검색·후보 목록과 누락 재검토·최소 보완 조합·자원-미지 행렬·추가 대안 및 미탐색 frontier 조사를 수행하는 것입니다. 반환물에는 항목별 조회표, 자원-미지 행렬, 부분 결과 조합표가 포함됩니다. 독립 조사가 실제로 범위나 속도에 도움이 될 때만 하위 작업을 나누며, 작업자는 leaf로 두고 재위임하지 않습니다. 하위 작업이 불가능하면 Coordinator에게 제한된 작업 brief를 돌려줍니다. Coordinator는 결과를 증거로 대조해야 하며, 조사 위임만으로 구매·비용이 큰 실험·배포·외부 변경 권한은 생기지 않습니다.

요청대로 파일 편집이나 연구 프로젝트 초기화는 하지 않았습니다.

실행 기록: 읽은 파일 `guide.txt`, `inputs/request-router1.txt`, `snapshot/skills/ris/SKILL.md`, `snapshot/skills/ris/references/role-workflow.md`, `snapshot/skills/ris/references/agent-installation.md`, `snapshot/skills/ris/references/research-exploration.md`, `snapshot/agents/researcher.toml`, `snapshot/templates/ris-coordinator-AGENTS.md`; 명령 `ls -la`, `cat`, `find old -maxdepth 4 -type f -printf '%P\\n' | sort`; 작업은 지정 record 파일 작성; 적용 역할 정의 `snapshot/agents/researcher.toml`.
