RIS Skill 관련 메타 질문으로 분류했습니다. 편집과 연구 초기화는 하지 않았습니다.

- **원본 파일:** 유지보수 지침상 편집 가능한 유일한 플러그인 원본은 `~/plugins/moontaehyung`입니다. RIS 본문은 `skills/ris/SKILL.md`이고, 제공된 snapshot 스냅샷에서는 `snapshot/skills/ris/SKILL.md`입니다. Researcher 역할 프롬프트는 `agents/researcher.toml`에 있습니다. 캐시 설치본과 폐기된 `moontaehyung-claude` 포크는 수정 대상이 아닙니다.
- **조사 위임:** Coordinator가 intake 및 범위가 크게 바뀔 때 필요한 역할과 의존성을 정하고, 입력이 준비된 독립 작업은 사용 가능하고 허용된 전문 역할에 배정합니다. Researcher 요청에는 전체 탐색인지 범위가 정해진 근거 확인인지, 구체적인 질문·결과, 제약, 영향받는 ID, 입력 출처와 revision, 산출물 형식/경로, 인수 기준, 허용 행동을 적습니다. 좁은 조사를 맡겨도 전체 탐색의 남은 범위와 프런티어는 Coordinator가 유지합니다.
- **Researcher 경계:** Researcher는 맡은 질문의 근거·대안·반대 근거·출처 위치와 실제 검토 범위·미해결 공백을 반환하고, 위임된 결과를 확인합니다. 독립적이고 범위가 분명한 하위 조사가 범위나 속도를 실질적으로 개선할 때만 auto-subagents를 활용하며, 작업자는 leaf로 둡니다. 역할이 추가 위임할 수 없는 환경에서는 Coordinator가 배정할 간결한 leaf 작업 brief를 반환합니다. Coordinator는 결과를 통합하고 경로의 타당성과 빠진 중요 대안을 함께 확인하며 전체 완료를 소유합니다.

참조한 실제 역할 정의: `snapshot/agents/researcher.toml` (`model = gpt-6.1-sol`, `model_reasoning_effort = medium`). 이 사례에서 실제 하위 에이전트 배정은 하지 않았습니다.

기록 메타: 읽은 파일 — `guide.txt`, `inputs/request-router1.txt`, `snapshot/skills/ris/SKILL.md`, `snapshot/skills/ris/references/maintenance.md`, `snapshot/skills/ris/references/agent-installation.md`, `snapshot/skills/ris/references/role-workflow.md`, `snapshot/agents/researcher.toml`; 수행 — 지정 리소스 읽기 및 요약, 기록 파일 작성; 역할 정의 — `snapshot/agents/researcher.toml` (Researcher).
