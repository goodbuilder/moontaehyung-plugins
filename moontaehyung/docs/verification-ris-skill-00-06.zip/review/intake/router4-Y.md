조사 역할 안내에 폭넓은 조사로 넘어가게 하는 지시가 있습니다. 다만 “자료 한 줄 확인도 반드시 넓혀라”는 문장이 직접 있는 것은 아니고, 좁은 요청에도 적용될 수 있는 무조건형 절차 때문에 그렇게 동작할 여지가 있습니다.

- `snapshot/agents/researcher.toml` 20–42행은 Researcher의 필수 절차를 “모든 단계 완료”로 규정합니다. 요청에 제품 등이 없어도 최소 세 가지 검색, 전체 후보 목록과 공백 재조사, 자원-미지 행렬, 조합 표, 목표를 만족하는 후보 외 추가 세 후보, 미탐색 프런티어 조사까지 요구합니다. 단순 한 줄 확인에 배정되면 범위를 크게 부풀리는 가장 직접적인 원인입니다.
- `snapshot/skills/ris/references/role-workflow.md` 3–8행은 필요한 역할을 질문이 하나뿐이어도 배정하라고 합니다. Researcher 호출 조건(14행)은 근거를 위한 bounded investigation이 필요한 경우라서 모든 사실 조회에 무조건 배정하라는 뜻은 아니지만, 배정된 뒤 위 무조건 절차가 발동할 수 있습니다.
- 반면 `snapshot/skills/ris/SKILL.md` 30–31행은 사실 확인이나 RIS 개선 질문을 “Narrow answer or meta question”으로 분류해 직접 답하고, 전체 후보 목록을 만들지 말며 조사 규율을 축소하라고 명시합니다. `snapshot/skills/ris/references/research-exploration.md` 146행에도 좁은 사실 답변에는 프로젝트 조사가 필요 없다고 적혀 있습니다.

따라서 지침은 서로 맞지 않습니다. 스킬 본문은 좁은 요청의 범위를 줄이지만, Researcher 설정의 “필수 절차 전부”가 그 예외를 보장하지 않습니다. 수정한다면 `snapshot/agents/researcher.toml`에 범위 게이트를 두어 실질적인 비교·순위화 조사에만 폭넓은 절차를 적용하고, 한정된 사실 조회는 필요한 출처 확인과 답변만 하도록 명시하는 것이 우선입니다. 역할 배정 규칙도 좁은 조회에는 Researcher를 배정하지 않아도 된다는 점을 이 분류와 일치시키면 모호성이 줄어듭니다. 이번 요청은 현재 지시 판독이므로 파일을 수정하지 않았습니다.

확인한 파일: `guide.txt`, `inputs/request-router4.txt`, `snapshot/skills/ris/SKILL.md`, `snapshot/agents/researcher.toml`, `snapshot/skills/ris/references/role-workflow.md`, `snapshot/skills/ris/references/research-exploration.md`; 실행: 지정 파일 읽기와 줄 번호 확인, 기록 파일 작성; 적용 역할: 일반 응답자(Researcher 역할 아님).
