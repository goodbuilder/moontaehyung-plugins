먼저 대상을 확인하고 싶습니다. 여기서 RIS는 (1) RIS 제품/저장소인가요, 아니면 (2) Codex의 RIS 스킬/플러그인인가요? 제품/저장소라면 문제가 나타나는 증상이나 오류도 함께 알려 주세요.

기록: 읽은 파일 — `guide.txt`, `inputs/request-router3.txt`, `snapshot/skills/ris/SKILL.md`; 실행/행동 — 위 파일을 읽고 모호성 라우팅 규칙 적용, 확인 질문 작성, 이 기록 파일 생성; 사용한 역할 정의 — RIS 스킬의 메인 스레드/Coordinator 라우팅 책임(전문 에이전트 호출 없음).
