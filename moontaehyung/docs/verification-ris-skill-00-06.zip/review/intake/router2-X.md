# 관찰 결과

관찰된 불일치는 한 가지입니다.

- `cli.py`의 `parse(argv)`는 `--format` 값으로 `text`와 `json`만 허용한다고 되어 있지만, README 예제는 `ris --format csv`를 안내합니다. `csv`는 명시된 허용값에 없으므로 이 예제는 인자 검증에서 거부됩니다.

제공된 두 발췌문만 비교했습니다. 앱 파일을 추가로 읽거나 실행·수정하지 않았으므로 기본값, 오류 문구, 다른 인자의 동작은 확인하지 않았습니다.

실행 기록: 읽은 파일 — `guide.txt`, `inputs/request-router2.txt`, `snapshot/skills/ris/SKILL.md`, `inputs/route-app.txt`; 작업 — 읽기 전용 발췌 비교 및 이 결과 기록; 사용한 역할 정의 — RIS 주 에이전트의 “Narrow answer or meta question” 경로, Researcher 역할·하위 에이전트 미사용.
