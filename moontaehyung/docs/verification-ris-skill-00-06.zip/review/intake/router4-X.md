# 현재 조사 역할 지침 검토

요청 분류: RIS 플러그인 역할 지침에 대한 좁은 메타 질문입니다. RIS Skill은 이런 요청을 maintenance와 플러그인 소스로 보내고, 좁은 답변·메타 질문에는 전체 후보 인벤토리를 돌리지 말라고 합니다 ([SKILL.md](snapshot/skills/ris/SKILL.md:20), [SKILL.md](snapshot/skills/ris/SKILL.md:33)).

## 판단

자료 한 줄 확인을 자동으로 폭넓은 조사로 승격하라는 규칙은 없습니다. Researcher 역할 지침은 배정 범위를 따르고, **전체 탐색**일 때만 완전한 폭넓은 조사 규율을 적용하며, **범위가 정해진 근거 확인**은 지정된 자료나 질문만 살펴서 발견·위치·적용 가능성·중요한 공백을 반환하고, 조회를 마치면 그 배정 질문만 해결된다고 명시합니다 ([researcher.toml](snapshot/agents/researcher.toml:20), [researcher.toml](snapshot/agents/researcher.toml:39)). Research-exploration 문서도 좁은 사실 확인에는 프로젝트 조사가 필요 없고, 점검은 요청 규모에 맞추라고 합니다 ([research-exploration.md](snapshot/skills/ris/references/research-exploration.md:144)).

다만 넓게 읽힐 수 있는 문구는 있습니다. RIS Skill은 “자율적으로 넓고 깊게 탐색”하라고 기본값을 제시하고, Researcher 역할은 반대 증거와 중요한 의존성을 재귀적으로 조사하라고 합니다 ([SKILL.md](snapshot/skills/ris/SKILL.md:68), [researcher.toml](snapshot/agents/researcher.toml:11)). 폭넓은 규율의 체크리스트도 출력 형식에 더해 여러 산출물을 요구합니다. 그러나 그 규율은 **접근법을 순위화하기 전**에 적용된다고 한정되어 있고, 좁은 답변의 예외가 별도로 적혀 있습니다 ([research-exploration.md](snapshot/skills/ris/references/research-exploration.md:55), [research-exploration.md](snapshot/skills/ris/references/research-exploration.md:146)). 따라서 한 줄의 의미나 출처를 확인하는 일은 범위가 정해진 근거 확인으로 처리하는 것이 현재 문구에 맞습니다. 그 한 줄에서 배정 질문에 영향을 주는 중요한 공백이 드러나면 공백을 보고하되, 그 사실만으로 전체 탐색이 자동 시작된다고 쓰여 있지는 않습니다.

수정한다면 역할 지침에 활성화 조건을 더 앞쪽에 못 박는 편이 좋겠습니다. 예를 들어 여러 접근법의 비교·순위화·탐색 계획을 요청했거나 명시적으로 전체 탐색으로 분류된 경우에만 전체 breadth 규율을 적용하고, 단일 자료·단일 주장 확인은 지정 자료, 근거 위치, 적용 가능성, 중요한 공백까지만 다루도록 적을 수 있습니다. 새로 드러난 공백이 더 넓은 질문을 만들면 우선 공백으로 반환하고, 별도 배정 없이 범위를 넓히지 않는다는 문장도 모호성을 줄입니다.

검토 범위에서는 지침만 읽었고 플러그인 파일은 변경하지 않았습니다.

검토 기록: 읽은 파일=guide.txt, inputs/request-router4.txt, snapshot/skills/ris/SKILL.md, snapshot/agents/researcher.toml, snapshot/skills/ris/references/maintenance.md, snapshot/skills/ris/references/research-exploration.md; 명령/조치=`cat`, `ls -la`, `rg -n -C 8`, `nl -ba ... | sed -n`, 출력 파일 작성 후 `cat`으로 확인; 실제 역할 정의=snapshot/agents/researcher.toml (`researcher`, `gpt-6.1-sol`, `medium`).
